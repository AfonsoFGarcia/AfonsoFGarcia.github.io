package pt.afonsogarcia.swiftbox.libswift.threads;

import android.content.ContentResolver;
import android.content.Context;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.net.Uri;
import android.provider.OpenableColumns;
import android.util.Log;
import android.widget.Toast;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpPut;
import org.apache.http.entity.InputStreamEntity;
import org.apache.http.entity.StringEntity;
import org.apache.http.params.CoreProtocolPNames;

import java.io.InputStream;

import pt.afonsogarcia.swiftbox.bundling.BundleNotFullException;
import pt.afonsogarcia.swiftbox.bundling.Bundler;
import pt.afonsogarcia.swiftbox.compression.CompressAPI;
import pt.afonsogarcia.swiftbox.domain.SwiftFile;
import pt.afonsogarcia.swiftbox.libswift.LibSwift;
import pt.afonsogarcia.swiftbox.ui.MainActivity;
import pt.afonsogarcia.swiftbox.ui.fragments.SwiftFolderFragment;

/**
 * Thread responsible for uploading a file to the server.
 * This class contains the adaptive and bundling decisions.
 * This class performs the upload if no adaptive compression is used.
 */
public class UploadFileThread extends LibSwiftThread {

    // Settings for adaptive compression and bundling
    public static Integer CHUNK_SIZE = 131072;
    public static Integer NUM_THREADS = 2;
    public static Boolean USE_ADAPT = true;
    public static Boolean USE_ASYNC = true;
    public static Boolean USE_BUNDLE = true;

    public static String CHUNK_PREF = "CHUNK_PREF";
    public static String THREADS_PREF = "THREADS_PREF";
    public static String ADAPT_PREF = "ADAPT_PREF";
    public static String ASYNC_PREF = "ASYNC_PREF";
    public static String BUNDLE_PREF = "BUNDLE_PREF";

    private Uri file;
    private ContentResolver resolver;
    private SwiftFolderFragment fragment;

    /**
     * Creates an UploadFileThread object
     * @param activity is an Android activity used to display the progress dialogs
     * @param file is the URI of the file being uploaded
     * @param resolver is the ContentResolver used to obtain the file name and size
     * @param fragment is the UI fragment of the folder where the file is being uploaded
     */
    public UploadFileThread(MainActivity activity, Uri file, ContentResolver resolver,
                            SwiftFolderFragment fragment) {
        super(activity, true);
        this.file = file;
        this.resolver = resolver;
        this.fragment = fragment;

        SharedPreferences preferences = activity.getSharedPreferences(MainActivity.PREFS_NAME,
                Context.MODE_PRIVATE);
        if(preferences.contains(CHUNK_PREF)) {
            CHUNK_SIZE = preferences.getInt(CHUNK_PREF, CHUNK_SIZE);
        }
        if (preferences.contains(THREADS_PREF)) {
            NUM_THREADS = preferences.getInt(THREADS_PREF, NUM_THREADS);
        }
        if (preferences.contains(ADAPT_PREF)) {
            USE_ADAPT = preferences.getBoolean(ADAPT_PREF, USE_ADAPT);
        }
        if (preferences.contains(ASYNC_PREF)) {
            USE_ASYNC = preferences.getBoolean(ASYNC_PREF, USE_ASYNC);
        }
        if (preferences.contains(BUNDLE_PREF)) {
            USE_BUNDLE = preferences.getBoolean(BUNDLE_PREF, USE_BUNDLE);
        }
    }

    /**
     * Adds file to the bundle (if bundling is used)
     * Uploads the file/bundle to the server (if adaptive compression is not used)
     * Passes the file/bundle to the chunk thread (if adaptive compression is used)
     */
    @Override
    @SuppressWarnings("deprecation")
    public void runWork() {
        try {
            // Get instance of LibSwift and CompressAPI
            LibSwift swift = LibSwift.getInstance();
            CompressAPI compressAPI = CompressAPI.getInstance(activity, true);

            // Decide if adaptive compression will be used
            Boolean useAdaptive = compressAPI.useAdaptive();

            // Get file name and size
            Cursor returnCursor = resolver.query(file, null, null, null, null);
            int nameIndex = returnCursor.getColumnIndex(OpenableColumns.DISPLAY_NAME);
            int sizeIndex = returnCursor.getColumnIndex(OpenableColumns.SIZE);
            returnCursor.moveToFirst();
            final String fileName = returnCursor.getString(nameIndex);
            String filePath = fragment.getFolder().getFullPath() + "/" + fileName;
            final Integer fileSize = returnCursor.getInt(sizeIndex);
            returnCursor.close();

            // Get InputStream with file contents
            InputStream in = resolver.openInputStream(file);

            HttpEntity entity;
            Boolean isBundle = false;

            Log.i("UploadFileThread", "Will use adaptive? " + (USE_ADAPT && useAdaptive));

            // If file size is smaller than bundling threshold and user defined bundling behaviour
            if(USE_BUNDLE && fileSize.longValue() < Bundler.THRESHOLD_SIZE) {
                Bundler bundler = Bundler.getInstance(activity);
                //for (Integer i = 0; i < 100; i++) // Remove comment for testing multiple files
                    bundler.addFile(filePath, fileSize.longValue(), resolver.openInputStream(file));

                // Displays file in UI
                fragment.getActivity().runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        SwiftFile file = new SwiftFile(fileName, fileSize.intValue(), "Unknown");
                        fragment.getFolder().addObject(file);
                        fragment.addSwiftObject();
                    }
                });

                // If bundle size is bigger than the threshold, upload bundle; otherwise inform user
                // that file was added to the bundle (catch clause)
                try {
                    in = bundler.getBundle();
                    isBundle = true;
                } catch (BundleNotFullException ignore) {
                    fragment.getActivity().runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            Toast.makeText(fragment.getActivity(), "File added to bundle!",
                                    Toast.LENGTH_SHORT).show();
                        }
                    });
                    return;
                }
            }

            String BUNDLE_URL = "/bundle/bundle_content.tar";

            // If user defined adaptive behaviour and estimation decided to use it, compute the
            // number of chunks and pass the file/bundle to the chunk thread; otherwise prepare
            // file/bundle for upload
            if(USE_ADAPT && useAdaptive) {
                final Integer blocks;
                if (isBundle)
                    blocks = Double.valueOf(Math.ceil(Integer.valueOf(in.available()).doubleValue()
                            / CHUNK_SIZE.doubleValue())).intValue();
                else
                    blocks = Double.valueOf(Math.ceil(fileSize.doubleValue() /
                            CHUNK_SIZE.doubleValue())).intValue();

                swift.setTotalChunks(blocks);

                swift.setAdaptstamp();

                if (isBundle)
                    swift.uploadChunks(in, blocks, BUNDLE_URL);
                else
                    swift.uploadChunks(in, blocks, filePath);

                // Wait until all chunks were uploaded
                synchronized (swift.lock) {
                    swift.lock.wait();
                }

                Boolean result = swift.hasFailed();

                // If any chunk failed upload, inform user and return
                if (result) {
                    fragment.getActivity().runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            Toast.makeText(fragment.getActivity(), "Error during uploads!",
                                    Toast.LENGTH_LONG).show();
                        }
                    });
                    return;
                }

                // Set upload entity with the number of chunks (next PUT will commit the chunks to
                // permanent storage and the content cannot be empty)
                entity = new StringEntity(blocks.toString());
            } else {
                if(isBundle)
                    entity = new InputStreamEntity(in, in.available());
                else
                    entity = new InputStreamEntity(in, fileSize.longValue());
            }

            HttpClient client = swift.getHttpClient();
            client.getParams().setBooleanParameter(CoreProtocolPNames.USE_EXPECT_CONTINUE, false);
            HttpPut put;

            // Set request headers for bundles, adaptive compression commit and
            // asynchronous behaviour
            if(isBundle) {
                put = swift.getHttpPut(BUNDLE_URL);
                put.addHeader("X-Bundle", "true");
                put.addHeader("X-Request-URL", swift.getRequestURL());
            } else
                put = swift.getHttpPut(filePath);
            if (USE_ADAPT && useAdaptive) {
                put.addHeader("X-Write-To-Core", "true");
            }
            if (USE_ASYNC) {
                put.addHeader("X-Write-Async", "true");
            }

            // Execute the PUT request
            put.setEntity(entity);

            // Consume server response
            final HttpResponse response = client.execute(put);
            response.getEntity().consumeContent();
            int statusCode = response.getStatusLine().getStatusCode();

            // Display file in the UI if upload was successful; otherwise inform the user of the
            // error
            if(statusCode >= 200 && statusCode < 300)
                fragment.getActivity().runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        SwiftFile file = new SwiftFile(fileName, fileSize.intValue(), "Unknown");
                        fragment.getFolder().addObject(file);
                        fragment.addSwiftObject();
                    }
                });
            else
                fragment.getActivity().runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        Toast.makeText(fragment.getActivity(), response.getStatusLine().toString(),
                                Toast.LENGTH_LONG).show();
                    }
                });
            swift.returnHttpClient(client);
        } catch (Exception e) {
            Log.e("UploadFileThread", e.getClass().getCanonicalName());
            e.printStackTrace();
        }
    }
}
