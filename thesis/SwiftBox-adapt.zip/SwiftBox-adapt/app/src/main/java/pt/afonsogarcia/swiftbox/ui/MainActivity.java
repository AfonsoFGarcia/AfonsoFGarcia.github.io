package pt.afonsogarcia.swiftbox.ui;

import android.app.ProgressDialog;
import android.app.admin.DevicePolicyManager;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.support.v4.app.DialogFragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.support.v7.app.ActionBarActivity;
import android.support.v7.internal.view.menu.MenuBuilder;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;

import java.util.LinkedList;

import pt.afonsogarcia.swiftbox.R;
import pt.afonsogarcia.swiftbox.admin.DeviceAdminReceiver;
import pt.afonsogarcia.swiftbox.domain.SwiftRootFolder;
import pt.afonsogarcia.swiftbox.ui.fragments.AboutFragment;
import pt.afonsogarcia.swiftbox.ui.fragments.InitialLoadFragment;
import pt.afonsogarcia.swiftbox.ui.fragments.NewFolderDialogFragment;
import pt.afonsogarcia.swiftbox.ui.fragments.SettingsFragment;
import pt.afonsogarcia.swiftbox.ui.fragments.SwiftFolderFragment;
import pt.afonsogarcia.swiftbox.ui.fragments.SwiftRootFolderFragment;

@SuppressWarnings("deprecation")
public class MainActivity extends ActionBarActivity
        implements FragmentManager.OnBackStackChangedListener {
    private Menu menu;
    private LinkedList<ProgressDialog> dialog;
    private SwiftFolderFragment currentFragment;

    public DevicePolicyManager manager;
    public ComponentName mDeviceAdmin;

    public static final String PREFS_NAME = "SwiftBoxPreferences";
    private static final String CUR_FRAG = "currentFragment";
    private static final int PICKFILE = 8951;
    public static final int ADMIN = 25895;

    @Override
    public void onSaveInstanceState(Bundle savedInstanceState) {
        super.onSaveInstanceState(savedInstanceState);
        if(currentFragment != null)
            getSupportFragmentManager().putFragment(savedInstanceState, CUR_FRAG,
                    currentFragment);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        if(savedInstanceState != null) {
            currentFragment = (SwiftFolderFragment) getSupportFragmentManager().
                    getFragment(savedInstanceState, CUR_FRAG);
            menu = new MenuBuilder(this);
            new MenuInflater(this).inflate(R.menu.menu_main, menu);
        }

        dialog = new LinkedList<>();

        setContentView(R.layout.activity_main);

        //noinspection ConstantConditions
        getSupportActionBar().setBackgroundDrawable(new ColorDrawable(Color.parseColor("#18515E")));
        getSupportFragmentManager().addOnBackStackChangedListener(this);
        shouldDisplayHomeUp();
        if(savedInstanceState == null)
            getSupportFragmentManager().beginTransaction()
                    .add(R.id.fragment, new InitialLoadFragment()).commit();

        manager = (DevicePolicyManager) getSystemService(Context.DEVICE_POLICY_SERVICE);
        mDeviceAdmin = new ComponentName(this, DeviceAdminReceiver.class);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        if(this.menu != null) {
            setMenu(menu);
        }
        this.menu = menu;
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
       switch (item.getItemId()) {
           case android.R.id.home:
               getSupportFragmentManager().popBackStack();
               break;
           case R.id.action_settings:
               getSupportFragmentManager().beginTransaction()
                       .replace(R.id.fragment, new SettingsFragment())
                       .addToBackStack(null).commit();
               break;
           case R.id.action_about:
               getSupportFragmentManager().beginTransaction()
                       .replace(R.id.fragment, new AboutFragment())
                       .addToBackStack(null).commit();
               break;
           case R.id.action_new_folder:
               SwiftFolderFragment rootFolder =
                       (SwiftFolderFragment) getSupportFragmentManager()
                               .findFragmentById(R.id.fragment);
               DialogFragment dialog = new NewFolderDialogFragment(rootFolder);
               dialog.show(getSupportFragmentManager(), null);
               break;
           case R.id.action_upload_file:
               SwiftFolderFragment folder =
                       (SwiftFolderFragment) getSupportFragmentManager()
                               .findFragmentById(R.id.fragment);
               getFile(folder);
               break;
       }

        return super.onOptionsItemSelected(item);
    }

    @Override
    public void onBackStackChanged() {
        shouldDisplayHomeUp();
    }

    private void shouldDisplayHomeUp() {
        boolean canBack = getSupportFragmentManager().getBackStackEntryCount() > 0;
        //noinspection ConstantConditions
        getSupportActionBar().setDisplayHomeAsUpEnabled(canBack);
    }

    @Override
    public void onBackPressed() {
        if(getSupportFragmentManager().getBackStackEntryCount() > 0)
            getSupportFragmentManager().popBackStack();
        else
            super.onBackPressed();
    }

    public void setMenu(boolean b) {
        menu.setGroupVisible(R.id.folder_group, b);
        menu.setGroupVisible(R.id.upload_group, b);
        menu.setGroupVisible(R.id.overflow_group, b);
    }

    public void setMenu(Menu menu) {
        menu.setGroupVisible(R.id.folder_group, this.menu.getItem(1).isVisible());
        menu.setGroupVisible(R.id.upload_group, this.menu.getItem(0).isVisible());
        menu.setGroupVisible(R.id.overflow_group, this.menu.getItem(2).isVisible());
    }

    public void setOverflowMenu(boolean b) {
        menu.setGroupVisible(R.id.overflow_group, b);
    }

    public void setUploadMenu(boolean b) {
        menu.setGroupVisible(R.id.upload_group, b);
    }

    public void displayRootFolder(SwiftRootFolder rootFolder) {
        getSupportFragmentManager().popBackStack(null, FragmentManager.POP_BACK_STACK_INCLUSIVE);
        final FragmentTransaction ft = getSupportFragmentManager().beginTransaction();
        ft.replace(R.id.fragment, new SwiftRootFolderFragment(rootFolder));
        ft.commit();
    }

    public void showDialog() {
        dialog.add(ProgressDialog.show(this, getResources().getString(R.string.empty),
                getResources().getString(R.string.wait_text), true));
    }

    public void dismissDialog() {
        ProgressDialog pd = dialog.removeFirst();
        if(pd != null)
            pd.dismiss();
    }

    public ProgressDialog showProgressDialog(int res, int max) {
        ProgressDialog pd = new ProgressDialog(this);
        pd.setTitle(R.string.empty);
        pd.setMessage(getResources().getString(res));
        pd.setProgressStyle(ProgressDialog.STYLE_HORIZONTAL);
        pd.setProgress(0);
        pd.setMax(max);
        pd.setCanceledOnTouchOutside(false);
        pd.show();
        dialog.add(pd);
        return pd;
    }

    public void getFile(SwiftFolderFragment currentFragment) {
        this.currentFragment = currentFragment;

        Intent intent = new Intent(Intent.ACTION_GET_CONTENT);
        intent.setType("*/*");
        startActivityForResult(intent, PICKFILE);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        switch (requestCode) {
            case PICKFILE:
                if(resultCode == RESULT_OK) {
                    Uri filePath = data.getData();
                    currentFragment.uploadFile(filePath);
                    currentFragment = null;
                }
                break;
        }
    }
}
