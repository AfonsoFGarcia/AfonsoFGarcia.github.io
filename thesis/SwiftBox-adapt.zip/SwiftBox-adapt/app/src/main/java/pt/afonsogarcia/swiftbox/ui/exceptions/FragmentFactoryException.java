package pt.afonsogarcia.swiftbox.ui.exceptions;

/**
 * FragmentFactoryException is an Exception wrapper for all exceptions thrown by the FragmentFactory
 */
public class FragmentFactoryException extends Exception {
    private Exception e;

    public FragmentFactoryException(Exception e) {
        this.e = e;
    }

    @Override
    public String getMessage() {
        return e.getMessage();
    }
}
