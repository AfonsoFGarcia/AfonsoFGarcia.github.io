package pt.afonsogarcia.swiftbox.libswift.exceptions;

/**
 * LibSwiftNotInitializedException is thrown when the app calls methods from LibSwift without
 * initializing it first.
 */
public class LibSwiftNotInitializedException extends Exception {
    @Override
    public String getMessage() {
        return "LibSwift is not initialized!";
    }
}
