package pt.afonsogarcia.swiftbox.ui.fragments;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import pt.afonsogarcia.swiftbox.domain.SwiftRootFolder;
import pt.afonsogarcia.swiftbox.ui.MainActivity;

@SuppressLint("ValidFragment")
public class SwiftRootFolderFragment extends SwiftFolderFragment {
    public SwiftRootFolderFragment(SwiftRootFolder folder) {
        super(folder);
    }

    public SwiftRootFolderFragment() {}

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = super.onCreateView(inflater, container, savedInstanceState);
        ((MainActivity)getActivity()).setUploadMenu(false);
        return view;
    }
}
