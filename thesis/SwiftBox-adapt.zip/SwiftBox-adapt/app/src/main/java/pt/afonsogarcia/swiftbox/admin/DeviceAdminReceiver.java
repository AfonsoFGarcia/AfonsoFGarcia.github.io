package pt.afonsogarcia.swiftbox.admin;

/**
 * This class is used to provide a device admin receiver. Since this is only used for turning the
 * display off and on, there is no need to override any of the methods, however this class is
 * necessary.
 */
public class DeviceAdminReceiver extends android.app.admin.DeviceAdminReceiver {
}
