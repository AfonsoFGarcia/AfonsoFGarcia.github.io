package pt.afonsogarcia.swiftbox.ui.helper;

import android.support.v4.app.Fragment;

import java.lang.reflect.Constructor;

import pt.afonsogarcia.swiftbox.domain.SwiftObject;
import pt.afonsogarcia.swiftbox.ui.exceptions.FragmentFactoryException;

/**
 * FragmentFactory receives a SwiftObject and creates the UI fragment for that object
 */
public class FragmentFactory {
    /**
     * Creates an UI fragment for the given object
     * @param object is the object for which the fragment will be created
     * @return the created UI fragment
     * @throws FragmentFactoryException when an exception is thrown
     */
    public static Fragment getFragmentFor(SwiftObject object) throws FragmentFactoryException {
        try {
            String fragmentClassName = "pt.afonsogarcia.swiftbox.ui.fragments." +
                    object.getClass().getSimpleName() + "Fragment";
            Class<?> fragmentClass = Class.forName(fragmentClassName);
            Constructor<?> fragmentConstructor = fragmentClass.getConstructor(object.getClass());
            return (Fragment) fragmentConstructor.newInstance(object);
        } catch (Exception e) {
            throw new FragmentFactoryException(e);
        }
    }
}
