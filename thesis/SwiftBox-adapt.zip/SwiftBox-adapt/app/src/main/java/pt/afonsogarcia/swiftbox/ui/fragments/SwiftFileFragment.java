package pt.afonsogarcia.swiftbox.ui.fragments;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v7.app.ActionBarActivity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import pt.afonsogarcia.swiftbox.R;
import pt.afonsogarcia.swiftbox.domain.SwiftFile;
import pt.afonsogarcia.swiftbox.libswift.threads.DownloadSwiftFileThread;
import pt.afonsogarcia.swiftbox.ui.MainActivity;

@SuppressWarnings("unused")
public class SwiftFileFragment extends Fragment {
    private SwiftFile file;

    public SwiftFileFragment() {
    }

    @SuppressLint("ValidFragment")
    public SwiftFileFragment(SwiftFile file) {
        this.file = file;
    }

    @Override
    @SuppressWarnings("deprecation")
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        //noinspection ConstantConditions
        if(savedInstanceState != null) {
            file = (SwiftFile) savedInstanceState.getSerializable("FILE");
        }
        //noinspection ConstantConditions
        ((ActionBarActivity)getActivity()).getSupportActionBar().setTitle(file.getName());
        ((MainActivity)getActivity()).setMenu(false);
        ((MainActivity)getActivity()).setOverflowMenu(true);

        View rootView = inflater.inflate(R.layout.fragment_file, container, false);

        TextView fn = (TextView) rootView.findViewById(R.id.fileName);
        fn.setText(file.getName() + "\n" + file.getContentType() + "\n" + file.getSize());

        Button button = (Button) rootView.findViewById(R.id.downloadButton);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                new DownloadSwiftFileThread(((MainActivity) getActivity()), file).start();
            }
        });

        return rootView;
    }

    @Override
    public void onSaveInstanceState(Bundle outState) {
        outState.putSerializable("FILE", file);
        super.onSaveInstanceState(outState);
    }

    public SwiftFile getFile() {
        return file;
    }
}
