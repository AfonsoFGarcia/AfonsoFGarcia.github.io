package pt.afonsogarcia.swiftbox.bundling;

import android.content.Context;
import android.content.SharedPreferences;

import org.apache.commons.compress.archivers.tar.TarArchiveEntry;
import org.apache.commons.compress.archivers.tar.TarArchiveOutputStream;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;

import pt.afonsogarcia.swiftbox.ui.MainActivity;

/**
 * Bundler provides the APIs necessary for bundling files. It is responsible for creating the
 * bundle and managing the thresholds.
 */
public class Bundler {
    private static Bundler instance;

    public static Long THRESHOLD_SIZE = 2097152L;
    public static Long MAX_SIZE = 10485760L;

    public static String THRESHOLD_PREF = "THRESHOLD_PREF";
    public static String MAX_PREF = "MAX_PREF";

    private ByteArrayOutputStream out;
    private TarArchiveOutputStream tarOut;
    private Long size;

    /**
     * Private constructor for the class (used for the singleton pattern)
     * @param activity is an Android activity for displaying toasts
     */
    private Bundler(MainActivity activity) {
        tarOut = new TarArchiveOutputStream((out = new ByteArrayOutputStream()));
        size = 0L;

        // Loads threshold values from memory if they are set
        SharedPreferences preferences = activity.getSharedPreferences(MainActivity.PREFS_NAME,
                Context.MODE_PRIVATE);
        if(preferences.contains(MAX_PREF)) {
            MAX_SIZE = preferences.getLong(MAX_PREF, MAX_SIZE);
        }
        if(preferences.contains(THRESHOLD_PREF)) {
            THRESHOLD_SIZE = preferences.getLong(THRESHOLD_PREF, THRESHOLD_SIZE);
        }
    }

    /**
     * Implements the singleton pattern for the class
     * @param activity is an Android activity for displaying toasts
     * @return instance of Bundler
     */
    public static Bundler getInstance(MainActivity activity) {
        if(instance == null)
            instance = new Bundler(activity);
        return instance;
    }

    /**
     * Destroys the current Bundler instance (used when changing threshold values)
     * @throws CannotDestroyBundlerException when there are files in the bundle
     */
    public static void destroyInstance() throws CannotDestroyBundlerException {
        if(instance != null && instance.size > 0L)
            throw new CannotDestroyBundlerException();
        instance = null;
    }

    /**
     * Adds a file to the bundle
     * @param name is the full name of the file inside the bundle
     * @param size is the file size
     * @param content is the InputStream containing the file content
     * @throws IOException when there is an error in the TarArchiveOutputStream
     */
    public void addFile(String name, Long size, InputStream content) throws IOException {
        TarArchiveEntry entry = new TarArchiveEntry(name);
        entry.setSize(size);
        this.size += size;
        tarOut.putArchiveEntry(entry);
        tarOut.write(getFileContent(content));
        tarOut.closeArchiveEntry();
    }

    /**
     * Produces a tar archive with the files included in the bundle
     * @return a InputStream with the tar archive
     * @throws BundleNotFullException when the bundle is smaller than the threshold
     * @throws IOException when there is an error in the TarArchiveOutputStream or in the
     * ByteArrayInputStream
     */
    public InputStream getBundle() throws BundleNotFullException, IOException {
        if(size < MAX_SIZE) {
            throw new BundleNotFullException();
        }
        tarOut.close();
        InputStream ret = new ByteArrayInputStream(out.toByteArray());
        out.close();

        // Creates new tar archive
        tarOut = new TarArchiveOutputStream((out = new ByteArrayOutputStream()));
        size = 0L;
        return ret;
    }

    /**
     * Reads the file from an InputStream to a byte array
     * @param in is an InputStream containing the file content
     * @return a byte array with the file content
     * @throws IOException when there is an error in the ByteArrayOutputStream
     */
    private byte[] getFileContent(InputStream in) throws IOException {
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        byte[] buffer = new byte[1024];
        int bytesRead;
        while ((bytesRead = in.read(buffer)) != -1)
            out.write(buffer, 0, bytesRead);
        in.close();
        return out.toByteArray();
    }
}
