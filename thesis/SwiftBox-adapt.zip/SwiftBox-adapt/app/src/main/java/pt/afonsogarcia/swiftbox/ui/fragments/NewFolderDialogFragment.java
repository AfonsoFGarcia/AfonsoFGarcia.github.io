package pt.afonsogarcia.swiftbox.ui.fragments;

import android.annotation.SuppressLint;
import android.app.Dialog;
import android.content.DialogInterface;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.v4.app.DialogFragment;
import android.support.v7.app.AlertDialog;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.EditText;

import pt.afonsogarcia.swiftbox.R;
import pt.afonsogarcia.swiftbox.domain.SwiftFolder;
import pt.afonsogarcia.swiftbox.libswift.threads.NewFolderThread;
import pt.afonsogarcia.swiftbox.ui.MainActivity;

@SuppressLint("ValidFragment")
public class NewFolderDialogFragment extends DialogFragment {
    SwiftFolderFragment folder;

    public NewFolderDialogFragment(SwiftFolderFragment folder) {
        this.folder = folder;
    }

    @NonNull
    @Override
    public Dialog onCreateDialog(Bundle savedInstanceState) {
        AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
        LayoutInflater inflater = getActivity().getLayoutInflater();
        @SuppressLint("InflateParams") final View layout = inflater
                .inflate(R.layout.new_folder_dialog, null);

        builder.setView(layout).
                setPositiveButton(R.string.ok_button, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        EditText nameView = (EditText) layout.findViewById(R.id.new_folder_name);
                        String name = nameView.getText().toString();
                        SwiftFolder newFolder = new SwiftFolder(name);
                        folder.getFolder().addObject(newFolder);
                        dialog.dismiss();
                        new NewFolderThread((MainActivity)getActivity(), newFolder, folder).start();
                    }
                }).setNegativeButton(R.string.cancel_button, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {

                    }
                }).setTitle("Create New Folder");

        return builder.create();
    }
}
