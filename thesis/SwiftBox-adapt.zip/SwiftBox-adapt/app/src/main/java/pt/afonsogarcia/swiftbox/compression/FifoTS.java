package pt.afonsogarcia.swiftbox.compression;

import java.util.LinkedList;

/**
 * Implements a thread safe version of a FIFO queue.
 */
public class FifoTS {
    /**
     * Represents an element of the FIFO.
     */
    public class FifoElem {
        private byte[] fileData;
        private Integer index;
        private String filePath;

        /**
         * Creates an element of the FIFO
         * @param index is the index of the chunk
         * @param fileData is the content of the chunk
         * @param filePath is the file path of the file to which the chunk belongs
         */
        public FifoElem(Integer index, byte[] fileData, String filePath) {
            this.fileData = fileData;
            this.index = index;
            this.filePath = filePath;
        }

        /**
         * Gets the chunk data
         * @return the chunk data
         */
        public byte[] getFileData() {
            return fileData;
        }

        /**
         * Gets the chunk index
         * @return the chunk index
         */
        public Integer getIndex() {
            return index;
        }

        /**
         * Gets the file path of the file to which the chunk belongs
         * @return the file path
         */
        public String getFilePath() {
            return filePath;
        }
    }

    // Object used for thread synchronization
    private final static Object lock = new Object();
    public static FifoTS instance;
    private LinkedList<FifoElem> fifo;

    /**
     * Private constructor for the class (used for the singleton pattern)
     */
    private FifoTS() {
        synchronized (lock) {
            fifo = new LinkedList<>();
        }
    }

    /**
     * Implements the singleton pattern for the class
     * @return instance of FifoTS
     */
    public static FifoTS getInstance() {
        synchronized (lock) {
            if (instance == null) {
                instance = new FifoTS();
            }
        }
        return instance;
    }

    /**
     * Puts an element into the end of the FIFO
     * @param index is the chunk index of the element being pushed
     * @param fileData is the chunk content of the element being pushed
     * @param filePath is the file path of the file to which the chunk being pushed belongs
     */
    public void pushFifo(Integer index, byte[] fileData, String filePath) {
        FifoElem push = new FifoElem(index, fileData, filePath);
        synchronized (lock) {
            fifo.addLast(push);
            lock.notify();
        }
    }

    /**
     * Gets an element from the beginning of the FIFO
     * @return the first element of the FIFO
     * @throws InterruptedException if there is an interruption caused by the scheduler
     */
    public FifoElem popFifo() throws InterruptedException {
        synchronized (lock) {
            if (fifo.size() == 0)
                lock.wait();
            return fifo.removeFirst();
        }
    }

    /**
     * Gets the current FIFO size
     * @return the FIFO size
     */
    public Integer getFifoSize() {
        synchronized (lock) {
            return fifo.size();
        }
    }
}
