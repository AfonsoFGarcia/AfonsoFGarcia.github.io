package pt.afonsogarcia.swiftbox.bundling;

/**
 * BundleNotFullException is thrown when the app tries to create a bundle but the provided files
 * are smaller than the bundling threshold.
 */
public class BundleNotFullException extends Exception {
}
