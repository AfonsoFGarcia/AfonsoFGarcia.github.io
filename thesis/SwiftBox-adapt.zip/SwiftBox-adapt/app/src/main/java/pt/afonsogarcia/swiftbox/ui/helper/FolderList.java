package pt.afonsogarcia.swiftbox.ui.helper;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.List;

import pt.afonsogarcia.swiftbox.R;
import pt.afonsogarcia.swiftbox.domain.SwiftFile;
import pt.afonsogarcia.swiftbox.domain.SwiftObject;

/**
 * Custom implementation of a UI list for SwiftObjects
 */
public class FolderList extends ArrayAdapter<SwiftObject> {
    private final Activity context;
    private final List<SwiftObject> objects;

    public FolderList(Activity context, List<SwiftObject> objects) {
        super(context, R.layout.folder_table_row, objects);
        this.context = context;
        this.objects = objects;
    }

    @Override
    public View getView(int position, View view, ViewGroup parent) {
        LayoutInflater inflater = context.getLayoutInflater();
        @SuppressLint({"ViewHolder", "InflateParams"})
        View rowView = inflater.inflate(R.layout.folder_table_row, null, true);
        TextView textView = (TextView) rowView.findViewById(R.id.name);
        ImageView imageView = (ImageView) rowView.findViewById(R.id.icon);

        SwiftObject object = objects.get(position);

        textView.setText(object.getName());

        if (object instanceof SwiftFile)
            imageView.setImageResource(R.drawable.file);
        else
            imageView.setImageResource(R.drawable.folder);

        return rowView;
    }
}
