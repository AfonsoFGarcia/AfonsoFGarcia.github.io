package pt.afonsogarcia.swiftbox.domain;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;

/**
 * Representation of a folder in the swift server.
 * A folder can be a container or an object.
 */
public class SwiftFolder extends SwiftObject {
    HashMap<String, SwiftObject> objects;

    /**
     * Creates a SwiftFolder object
     * @param name the name of the folder
     */
    public SwiftFolder(String name) {
        super(name);
        objects = new HashMap<>();
    }

    /**
     * Adds an object to the folder
     * @param object is the object to add
     */
    public void addObject(SwiftObject object) {
        object.setParent(this);
        objects.put(object.getName(), object);
    }

    /**
     * Gets a list of all objects contained within the folder
     * @return the list of objects
     */
    public List<SwiftObject> getObjects() {
        List<SwiftObject> objects = new ArrayList<>(this.objects.values());
        Collections.sort(objects, new SwiftObjectComparator());
        return objects;
    }

    /**
     * Gets a object contained within the folder by name
     * @param name is the name of the object
     * @return the object
     */
    public SwiftObject getObject(String name) {
        return objects.get(name);
    }
}
