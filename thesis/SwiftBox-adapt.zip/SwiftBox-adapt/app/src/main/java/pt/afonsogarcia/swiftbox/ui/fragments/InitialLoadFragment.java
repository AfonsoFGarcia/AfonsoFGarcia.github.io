package pt.afonsogarcia.swiftbox.ui.fragments;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v7.app.ActionBarActivity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;

import pt.afonsogarcia.swiftbox.R;
import pt.afonsogarcia.swiftbox.libautomator.LibAutomator;
import pt.afonsogarcia.swiftbox.libswift.LibSwift;
import pt.afonsogarcia.swiftbox.libswift.threads.UploadFileThread;
import pt.afonsogarcia.swiftbox.ui.MainActivity;

public class InitialLoadFragment extends Fragment {
    public final static String URL_PREF = "URLPref";
    public final static String USER_PREF = "UserPref";
    public final static String PASS_PREF = "PassPref";

    public InitialLoadFragment() {
    }

    @Override
    @SuppressWarnings("deprecation")
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        //noinspection ConstantConditions
        ((ActionBarActivity)getActivity()).getSupportActionBar().setTitle("SwiftBox");

        final View inflatedView = inflater.inflate(R.layout.fragment_initial_load, container,
                false);

        SharedPreferences preferences = getActivity().getSharedPreferences(MainActivity.PREFS_NAME,
                Context.MODE_PRIVATE);

        Button refresh = (Button) inflatedView.findViewById(R.id.loginButton);
        refresh.setOnClickListener(new SwiftInit(inflatedView, ((MainActivity) getActivity())));

        // Loads authentication URL, username and password from preferences and authenticates user
        if(preferences.contains(URL_PREF)) {
            String url = preferences.getString(URL_PREF, null);
            String user = preferences.getString(USER_PREF, null);
            String pass = preferences.getString(PASS_PREF, null);
            Integer numThreads = preferences.getInt(UploadFileThread.THREADS_PREF,
                    UploadFileThread.NUM_THREADS);

            ((EditText)inflatedView.findViewById(R.id.authURLText)).setText(url);
            ((EditText)inflatedView.findViewById(R.id.usernameText)).setText(user);
            ((EditText)inflatedView.findViewById(R.id.passwordText)).setText(pass);

            LibAutomator.initLibAutomator((MainActivity) getActivity());
            LibSwift swift = LibSwift.initialize(url, user, pass, numThreads, getActivity());
            swift.auth(((MainActivity) getActivity()));
        }

        // Loads preferences for adaptive compression
        if(!preferences.contains(UploadFileThread.CHUNK_PREF)) {
            preferences.edit().putInt(UploadFileThread.CHUNK_PREF, UploadFileThread.CHUNK_SIZE)
                    .commit();
        }
        if(!preferences.contains(UploadFileThread.THREADS_PREF)) {
            preferences.edit().putInt(UploadFileThread.THREADS_PREF, UploadFileThread.NUM_THREADS)
                    .commit();
        }

        if(!preferences.contains(UploadFileThread.ADAPT_PREF)) {
            preferences.edit().putBoolean(UploadFileThread.ADAPT_PREF, UploadFileThread.USE_ADAPT)
                    .commit();
        }

        if(!preferences.contains(UploadFileThread.ASYNC_PREF)) {
            preferences.edit().putBoolean(UploadFileThread.ASYNC_PREF, UploadFileThread.USE_ASYNC)
                    .commit();
        }

        return inflatedView;
    }

    /**
     * Implements OnClickListener for login button
     */
    private class SwiftInit implements View.OnClickListener {
        private View inflatedView;
        private MainActivity activity;

        public SwiftInit(View inflatedView, MainActivity activity) {
            this.inflatedView = inflatedView;
            this.activity = activity;
        }

        @Override
        public void onClick(View v) {
            String authURL = ((EditText)inflatedView.findViewById(R.id.authURLText))
                    .getText().toString();
            String username = ((EditText)inflatedView.findViewById(R.id.usernameText))
                    .getText().toString();
            String password = ((EditText)inflatedView.findViewById(R.id.passwordText))
                    .getText().toString();

            LibAutomator.initLibAutomator((MainActivity) getActivity());
            LibSwift swift = LibSwift.initialize(authURL, username, password,
                    UploadFileThread.NUM_THREADS, getActivity());
            swift.auth(activity);
        }
    }
}
