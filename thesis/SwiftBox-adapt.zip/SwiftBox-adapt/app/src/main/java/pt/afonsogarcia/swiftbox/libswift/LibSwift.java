package pt.afonsogarcia.swiftbox.libswift;

import android.app.Activity;
import android.util.Log;

import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPut;
import org.apache.http.conn.ClientConnectionManager;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.impl.conn.tsccm.ThreadSafeClientConnManager;
import org.apache.http.params.CoreProtocolPNames;
import org.apache.http.params.HttpParams;

import java.io.InputStream;
import java.net.URI;
import java.net.URL;
import java.util.concurrent.LinkedBlockingQueue;

import pt.afonsogarcia.swiftbox.compression.threads.CreateChunkThread;
import pt.afonsogarcia.swiftbox.compression.threads.UploadChunkThread;
import pt.afonsogarcia.swiftbox.libswift.exceptions.LibSwiftNotInitializedException;
import pt.afonsogarcia.swiftbox.libswift.threads.AuthThread;
import pt.afonsogarcia.swiftbox.libswift.threads.SwiftRootFolderThread;
import pt.afonsogarcia.swiftbox.ui.MainActivity;

/**
 * LibSwift implements a set of methods designed to help interact with the swift API.
 */
public class LibSwift {
    private static LibSwift instance;

    // Used to synchronize between threads
    public final Object lock = new Object();

    // Used for waiting until new file is available
    public final Object fileLock = new Object();

    private String authURL;
    private String username;
    private String password;
    private Integer numThreads;

    private String requestURL = null;
    private String authToken = null;

    private Integer totalChunks;
    private Integer processedChunks;
    private Boolean failed;

    private FileChunkData data;

    private Long adaptstamp;

    private UploadChunkThread uploadChunkThreads[];
    private CreateChunkThread createChunkThread;

    @SuppressWarnings("deprecation")
    private LinkedBlockingQueue<HttpClient> httpClients;

    /**
     * Private constructor for the class (used for the singleton pattern)
     * @param authURL is the URL of the server for performing authentication
     * @param username is the username of the user to authenticate
     * @param password is the password of the user to authenticate
     * @param numThreads is the number of threads used to upload objects to the server
     * @param activity is an Android activity used for passing to the CreateChunkThread
     */
    private LibSwift(String authURL, String username, String password, Integer numThreads,
                     Activity activity) {
        this.authURL = authURL;
        this.username = username;
        this.password = password;
        this.numThreads = numThreads;
        this.uploadChunkThreads = new UploadChunkThread[numThreads];

        // Creates numThreads UploadChunkThread
        for (int i = 0; i < numThreads; i++) {
            this.uploadChunkThreads[i] = new UploadChunkThread();
        }

        this.createChunkThread = new CreateChunkThread(activity);

        this.totalChunks = 0;
        this.processedChunks = 0;
        this.adaptstamp = 0L;

        this.httpClients = new LinkedBlockingQueue<>();
    }

    /**
     * Implements the singleton pattern for the class
     * @param authURL is the URL of the server for performing authentication
     * @param username is the username of the user to authenticate
     * @param password is the password of the user to authenticate
     * @param numThreads is the number of threads used to upload objects to the server
     * @param activity is an Android activity used for passing to the CreateChunkThread
     * @return instance of LibSwift
     */
    public static LibSwift initialize(String authURL, String username, String password,
                                      Integer numThreads, Activity activity) {
        if(instance == null) {
            instance = new LibSwift(authURL, username, password, numThreads, activity);

            // Starts numThreads UploadChunkThread
            for (int i = 0; i < numThreads; i++) {
                instance.uploadChunkThreads[i].start();
            }

            instance.createChunkThread.start();
        } else {
            instance.authURL = authURL;
            instance.username = username;
            instance.password = password;
        }

        return instance;
    }

    // Sets the timestamp used for the chunks in upload (used to identify correct chunks during
    // multiple uploads or in case of upload failure)
    public void setAdaptstamp() {
        adaptstamp = System.currentTimeMillis();
    }

    // Creates or deletes UploadChunkThread based on the new numThreads
    public void modifyNumberOfThreads(Integer numThreads) {
        Integer currentNumThreads = uploadChunkThreads.length;
        if(numThreads < currentNumThreads) {
            UploadChunkThread[] newThreads = new UploadChunkThread[numThreads];
            for(int i = 0; i < currentNumThreads; i++) {
                if(i < numThreads) {
                    newThreads[i] = uploadChunkThreads[i];
                } else {
                    uploadChunkThreads[i].killThread();
                }
            }
            uploadChunkThreads = newThreads;
        } else if (numThreads > currentNumThreads) {
            UploadChunkThread[] newThreads = new UploadChunkThread[numThreads];
            for(int i = 0; i < numThreads; i++) {
                if(i < currentNumThreads) {
                    newThreads[i] = uploadChunkThreads[i];
                } else {
                    newThreads[i] = new UploadChunkThread();
                    newThreads[i].start();
                }
            }
            uploadChunkThreads = newThreads;
        }
    }

    /**
     * Implements the singleton pattern for the class
     * @return instance of LibSwift
     * @throws LibSwiftNotInitializedException when LibSwift was not initialized
     */
    public static LibSwift getInstance() throws LibSwiftNotInitializedException{
        if(instance == null) {
            throw new LibSwiftNotInitializedException();
        }
        return instance;
    }

    /**
     * Authenticates the user
     * @param activity is an Android activity used to display the progress dialogs
     */
    public void auth(MainActivity activity) {
        new AuthThread(activity, authURL, username, password, numThreads).start();
    }

    /**
     * Gets the root folder for the user
     * @param activity is an Android activity used to display the progress dialogs
     */
    public void getRootFolder(MainActivity activity) {
        new SwiftRootFolderThread(activity).start();
    }

    /**
     * Sets the authentication token for the user
     * @param requestURL is the URL used to perform requests to the server
     * @param authToken is the token used to authenticate the user
     */
    public void setAuthToken(String requestURL, String authToken) {
        synchronized (this) {
            this.requestURL = requestURL;
            this.authToken = authToken;
        }
    }

    /**
     * Verifies if the user is authenticated
     * @return true if the user is authenticated, false otherwise
     */
    public boolean isAuthed() {
        synchronized (this) {
            return requestURL != null && authToken != null;
        }
    }

    /**
     * Gets an HttpGet object for performing GET requests
     * @param path is the object path
     * @return an HttpGet object
     */
    @SuppressWarnings("deprecation")
    public HttpGet getRawHttpGet(String path) {
        try {
            String fullPath = requestURL + path;
            URL url = new URL(fullPath);
            URI uri = new URI(url.getProtocol(), url.getUserInfo(), url.getHost(), url.getPort(),
                    url.getPath(), url.getQuery(), url.getRef());
            HttpGet get = new HttpGet(uri.toASCIIString());
            get.addHeader("X-Storage-Token", authToken);
            return get;
        } catch (Exception e) {
            Log.e("LibSwift", e.getMessage());
            return null;
        }
    }

    /**
     * Gets an HttpGet object for performing GET requests on the root folder with JSON formatting
     * @return an HttpGet object
     */
    @SuppressWarnings("deprecation")
    public HttpGet getHttpGet() {
        return getHttpGet("");
    }

    /**
     * Gets an HttpGet object for performing GET requests with JSON formatting
     * @param path is the object path
     * @return an HttpGet object
     */
    @SuppressWarnings("deprecation")
    public HttpGet getHttpGet(String path) {
        return getRawHttpGet(path + "?format=json");
    }

    /**
     * Gets an HttpPut object for performing PUT requests
     * @param path is the object path
     * @return an HttpPut object
     */
    @SuppressWarnings("deprecation")
    public HttpPut getHttpPut(String path) {
        try {
            String fullPath = requestURL + path;
            URL url = new URL(fullPath);
            URI uri = new URI(url.getProtocol(), url.getUserInfo(), url.getHost(), url.getPort(),
                    url.getPath(), url.getQuery(), url.getRef());
            HttpPut put = new HttpPut(uri.toASCIIString());
            put.addHeader("X-Storage-Token", authToken);
            put.addHeader("X-Adaptstamp", adaptstamp.toString());
            return put;
        } catch (Exception e) {
            Log.e("LibSwift", e.getMessage());
            return null;
        }
    }

    /**
     * Gets an HTTP client initialized to talk to the swift server
     * @return an HttpClient object
     * @throws InterruptedException when there is an interruption from the scheduler
     */
    @SuppressWarnings("deprecation")
    public HttpClient getHttpClient() throws InterruptedException {
        if(httpClients.isEmpty()) {
            HttpClient client = new DefaultHttpClient();
            ClientConnectionManager manager = client.getConnectionManager();
            HttpParams params = client.getParams();
            params.setParameter(CoreProtocolPNames.USER_AGENT, "SwiftBox");
            return new DefaultHttpClient(new ThreadSafeClientConnManager(params,
                    manager.getSchemeRegistry()), params);
        } else {
            return httpClients.take();
        }
    }

    /**
     * Returns an HTTP client to the client pool
     * @param client is the HttpClient to be returned
     * @throws InterruptedException when there is an interruption from the scheduler
     */
    @SuppressWarnings("deprecation")
    public void returnHttpClient(HttpClient client) throws InterruptedException {
        httpClients.put(client);
    }

    /**
     * Sets the total number of chunks that will be uploaded
     * @param totalChunks is the number of chunks that will be uploaded
     */
    public void setTotalChunks(Integer totalChunks) {
        synchronized (lock) {
            this.totalChunks = totalChunks;
            this.processedChunks = 0;
            this.failed = false;
        }
    }

    /**
     * Increments the number of chunks that were already uploaded
     */
    public void incrementProcessedChunks() {
        synchronized (lock) {
            this.processedChunks++;
            if(this.processedChunks.equals(this.totalChunks)) {
                lock.notify(); // Notifies UploadFileThread that all chunks were uploaded
            }
        }
    }

    /**
     * Sets the failed flag indicating that a chunk upload has failed
     */
    public void setFailedFlag() {
        synchronized (lock) {
            this.failed = true;
        }
    }

    /**
     * Verifies if any chunk upload has failed
     * @return true if any upload failed, false otherwise
     */
    public Boolean hasFailed() {
        synchronized (lock) {
            return this.failed;
        }
    }

    /**
     * Sets number of created chunks (used when there was an error creating the chunks)
     * @param chunks is the number of created chunks
     */
    public void setFinalChunks(Integer chunks) {
        synchronized (lock) {
            this.totalChunks = chunks;
        }
    }

    /**
     * Uploads a file in chunks to the server
     * @param in is the InputStream containing the file data
     * @param chunkNumber is the number of chunks that will be created
     * @param filePath is the file path of the file being uploaded
     */
    public void uploadChunks(InputStream in, Integer chunkNumber, String filePath) {
        synchronized (fileLock) {
            data = new FileChunkData(in, chunkNumber, filePath);
            fileLock.notify(); // Notify the CreateChunkThread that a new file is available
        }
    }

    /**
     * Gets the file data for creating the chunks
     * @return the information about the file to be split into chunks
     * @throws InterruptedException when there is an interruption from the scheduler
     */
    public FileChunkData getData() throws InterruptedException {
        synchronized (fileLock) {
            fileLock.wait(); // CreateChunkThread waits here for a new file
            return data;
        }
    }

    /**
     * Information about the file to be passed to the chunk thread
     */
    public class FileChunkData {
        private InputStream in;
        private Integer chunkNumber;
        private String filePath;

        /**
         * Creates a FileChunkData object
         * @param in is the InputStream containing the file data
         * @param chunkNumber is the number of chunks that will be created
         * @param filePath is the file path of the file being uploaded
         */
        public FileChunkData(InputStream in, Integer chunkNumber, String filePath) {
            this.in = in;
            this.chunkNumber = chunkNumber;
            this.filePath = filePath;
        }

        /**
         * Gets the InputStream containing the file data
         * @return the InputStream
         */
        public InputStream getInputStream() {
            return in;
        }

        /**
         * Gets the number of chunks that will be created
         * @return the number of chunks
         */
        public Integer getChunkNumber() {
            return chunkNumber;
        }

        /**
         * Gets the file path of the file being uploaded
         * @return the file path
         */
        public String getFilePath() {
            return filePath;
        }
    }

    public String getRequestURL() {
        return requestURL;
    }
}
