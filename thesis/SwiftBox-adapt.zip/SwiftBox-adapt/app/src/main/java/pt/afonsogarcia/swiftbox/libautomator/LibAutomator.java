package pt.afonsogarcia.swiftbox.libautomator;

import android.app.KeyguardManager;
import android.content.Context;
import android.os.PowerManager;
import android.util.Log;

import java.io.IOException;
import java.math.BigDecimal;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;

import pt.afonsogarcia.swiftbox.ui.MainActivity;

/**
 * LibAutomator works with a server on the computer to automate energy measurement with a Monsoon
 * Power Monitor.
 * The automation server only runs on Windows, due to the Monsoon software not supporting other
 * platforms. Visual Studio is required to build the server.
 * The IP address of the server needs to be modified in code and if it changes, a new build must be
 * uploaded to the mobile device with it updated.
 * @see <a href="https://github.com/AfonsoFGarcia/Automation">Server GitHub Repository</a>
 */
public class LibAutomator {
    private static Long startTime;
    private static DatagramSocket socket;
    private static InetAddress address;
    private static MainActivity activity;

    /**
     * Initialize the UDP socket
     * @param act is an Android activity used to control the phone screen
     */
    public static void initLibAutomator(MainActivity act) {
        try {
            socket = new DatagramSocket();
            address = InetAddress.getByName("86.50.146.159");
            activity = act;
        } catch (Exception ignore) {
            Log.e("LibAutomator", "Could not create UDP socket");
        }
    }

    /**
     * Starts the measurements
     * @param power is a flag to control if a message for starting to measure power should be sent
     * @param screen is a flag to control if the screen should turn off
     * @throws InterruptedException if there is an interruption caused by the scheduler
     */
    public static void startMeasurements(Boolean power, Boolean screen)
            throws InterruptedException {
        if (screen) {
            activity.manager.lockNow();
            if(!power)
                Thread.sleep(3000);
        }
        if (power) {
            sendData("ON".getBytes());
            String msg = receiveData();
            if(msg == null || msg.equals("FAIL"))
                Log.e("LibAutomator", "Received FAIL from Automator");
        }
        startTime = System.nanoTime();
    }

    /**
     * Sends data to the server
     * @param data is the data to send
     */
    private static void sendData(byte[] data) {
        DatagramPacket packet = new DatagramPacket(data, data.length, address, 50000);
        try {
            socket.send(packet);
        } catch (IOException ignore) {
            Log.e("LibAutomator", "Could not send UDP packet");
        }
    }

    /**
     * Receives data from the server (blocks until something is received)
     * @return the data received
     */
    private static String receiveData() {
        byte[] buffer = new byte[8];

        DatagramPacket packet = new DatagramPacket(buffer, buffer.length);
        try {
            socket.receive(packet);
            return new String(buffer, 0, packet.getLength());
        } catch (IOException ignore) {
            Log.e("LibAutomator", "Could not send UDP packet");
            return null;
        }
    }

    /**
     * Stops the measurements
     * @param power is a flag to control if a message for stopping to measure power should be sent
     * @param screen is a flag to control if the screen should turn on
     * @return the execution time
     * @throws InterruptedException if there is an interruption caused by the scheduler
     */
    @SuppressWarnings("deprecation")
    public static Double stopMeasurements(Boolean power, Boolean screen)
            throws InterruptedException {
        Double time = round((System.nanoTime() - startTime) / 1000000000d);
        if (power) {
            sendData("OFF".getBytes());
            String msg = receiveData();
            if(msg == null || msg.equals("FAIL"))
                Log.e("LibAutomator", "Received FAIL from Automator");
        }
        if (screen) {
            if (!power) {
                Thread.sleep(3000);
            }
            PowerManager powerManager = (PowerManager) activity
                    .getSystemService(Context.POWER_SERVICE);
            PowerManager.WakeLock wakeLock = powerManager
                    .newWakeLock((PowerManager.SCREEN_BRIGHT_WAKE_LOCK
                    | PowerManager.FULL_WAKE_LOCK | PowerManager.ACQUIRE_CAUSES_WAKEUP)
                            , "LibAutomatorPower");
            wakeLock.acquire();
            KeyguardManager keyguardManager = (KeyguardManager) activity
                    .getSystemService(Context.KEYGUARD_SERVICE);
            KeyguardManager.KeyguardLock keyguardLock = keyguardManager
                    .newKeyguardLock("LibAutomatorKey");
            keyguardLock.disableKeyguard();
            wakeLock.release();
        }
        return time;
    }

    /**
     * Rounds a value to 3 decimal places
     * @param value is the value to round
     * @return the rounded value
     */
    public static Double round(Double value) {
        BigDecimal bd = new BigDecimal(value);
        bd = bd.setScale(3, BigDecimal.ROUND_HALF_UP);
        return bd.doubleValue();
    }
}
