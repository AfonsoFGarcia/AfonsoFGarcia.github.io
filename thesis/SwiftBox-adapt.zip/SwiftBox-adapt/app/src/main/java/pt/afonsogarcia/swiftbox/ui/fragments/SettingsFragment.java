package pt.afonsogarcia.swiftbox.ui.fragments;

import android.app.admin.DevicePolicyManager;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v7.app.ActionBarActivity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.Toast;

import pt.afonsogarcia.swiftbox.R;
import pt.afonsogarcia.swiftbox.bundling.Bundler;
import pt.afonsogarcia.swiftbox.bundling.CannotDestroyBundlerException;
import pt.afonsogarcia.swiftbox.compression.CompressAPI;
import pt.afonsogarcia.swiftbox.libswift.LibSwift;
import pt.afonsogarcia.swiftbox.libswift.exceptions.LibSwiftNotInitializedException;
import pt.afonsogarcia.swiftbox.libswift.threads.UploadFileThread;
import pt.afonsogarcia.swiftbox.ui.MainActivity;

public class SettingsFragment extends Fragment {

    public SettingsFragment() {
    }

    @Override
    @SuppressWarnings("deprecation")
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View layout = inflater.inflate(R.layout.fragment_settings, container, false);

        //noinspection ConstantConditions
        ((ActionBarActivity) getActivity()).getSupportActionBar().setTitle("Settings");
        ((MainActivity)getActivity()).setMenu(false);

        // Gets current values of all settings
        final SharedPreferences preferences = getActivity()
                .getSharedPreferences(MainActivity.PREFS_NAME, Context.MODE_PRIVATE);
        String url = preferences.getString(InitialLoadFragment.URL_PREF, null);
        String user = preferences.getString(InitialLoadFragment.USER_PREF, null);
        String pass = preferences.getString(InitialLoadFragment.PASS_PREF, null);
        Integer chunk = preferences
                .getInt(UploadFileThread.CHUNK_PREF, UploadFileThread.CHUNK_SIZE);
        Integer numT = preferences
                .getInt(UploadFileThread.THREADS_PREF, UploadFileThread.NUM_THREADS);
        Boolean adapt = preferences
                .getBoolean(UploadFileThread.ADAPT_PREF, UploadFileThread.USE_ADAPT);
        Boolean async = preferences
                .getBoolean(UploadFileThread.ASYNC_PREF, UploadFileThread.USE_ASYNC);
        Long max = preferences.getLong(Bundler.MAX_PREF, Bundler.MAX_SIZE);
        Long thrs = preferences.getLong(Bundler.THRESHOLD_PREF, Bundler.THRESHOLD_SIZE);
        Boolean bundle = preferences
                .getBoolean(UploadFileThread.BUNDLE_PREF, UploadFileThread.USE_BUNDLE);
        Float compressionConstant = preferences
                .getFloat(CompressAPI.SETTING_CONSTANT, CompressAPI.COMPRESSION_CONSTANT);
        Float compressionRatio = preferences
                .getFloat(CompressAPI.SETTING_RATIO, CompressAPI.COMPRESSION_RATIO);
        Integer networkSpeed = preferences
                .getInt(CompressAPI.SETTING_SPEED, CompressAPI.NETWORK_SPEED);
        Boolean preferPower = preferences
                .getBoolean(CompressAPI.SETTING_POWER, CompressAPI.PREFER_POWER);

        // Gets textboxes for all settings and sets them with the current values
        final EditText authURL = (EditText) layout.findViewById(R.id.changeAuthURL);
        authURL.setText(url);
        final EditText username = (EditText) layout.findViewById(R.id.changeUsername);
        username.setText(user);
        final EditText password = (EditText) layout.findViewById(R.id.changePassword);
        password.setText(pass);
        final EditText chunk_size = (EditText) layout.findViewById(R.id.changeChunkSize);
        chunk_size.setText(String.valueOf(chunk));
        final EditText num_threads = (EditText) layout.findViewById(R.id.changeNumThreads);
        num_threads.setText(String.valueOf(numT));
        final EditText max_size = (EditText) layout.findViewById(R.id.changeBundleSize);
        max_size.setText(String.valueOf(max));
        final EditText threshold_size = (EditText) layout.findViewById(R.id.changeThreshold);
        threshold_size.setText(String.valueOf(thrs));
        final CheckBox use_adapt = (CheckBox) layout.findViewById(R.id.useAdapt);
        use_adapt.setChecked(adapt);
        final CheckBox use_async = (CheckBox) layout.findViewById(R.id.useAsync);
        use_async.setChecked(async);
        final CheckBox use_bundle = (CheckBox) layout.findViewById(R.id.useBundle);
        use_bundle.setChecked(bundle);
        final EditText comp_const = (EditText) layout.findViewById(R.id.changeCompressionConstant);
        comp_const.setText(String.valueOf(compressionConstant));
        final EditText comp_ratio = (EditText) layout.findViewById(R.id.changeCompressionRatio);
        comp_ratio.setText(String.valueOf(compressionRatio));
        final EditText net_speed = (EditText) layout.findViewById(R.id.changeNetworkSpeed);
        net_speed.setText(String.valueOf(networkSpeed));
        final CheckBox power_sav = (CheckBox) layout.findViewById(R.id.preferPower);
        power_sav.setChecked(preferPower);

        // Enable bundling options and disable async option
        if(bundle) {
            use_async.setChecked(true);
            use_async.setEnabled(false);
            max_size.setEnabled(true);
            threshold_size.setEnabled(true);
        } else {
            use_async.setEnabled(true);
            max_size.setEnabled(false);
            threshold_size.setEnabled(false);
        }

        // Enable adaptive compression options
        if(adapt) {
            chunk_size.setEnabled(true);
            num_threads.setEnabled(true);
            comp_const.setEnabled(true);
            comp_ratio.setEnabled(true);
            net_speed.setEnabled(true);
            power_sav.setEnabled(true);
        } else {
            chunk_size.setEnabled(false);
            num_threads.setEnabled(false);
            comp_const.setEnabled(false);
            comp_ratio.setEnabled(false);
            net_speed.setEnabled(false);
            power_sav.setEnabled(false);
        }

        // Set OnClickListener for bundling options
        use_bundle.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(use_bundle.isChecked()) {
                    use_async.setChecked(true);
                    use_async.setEnabled(false);
                    max_size.setEnabled(true);
                    threshold_size.setEnabled(true);
                } else {
                    use_async.setEnabled(true);
                    max_size.setEnabled(false);
                    threshold_size.setEnabled(false);
                }
            }
        });

        // Set OnClickListener for adaptive compression options
        use_adapt.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(use_adapt.isChecked()) {
                    chunk_size.setEnabled(true);
                    num_threads.setEnabled(true);
                    comp_const.setEnabled(true);
                    comp_ratio.setEnabled(true);
                    net_speed.setEnabled(true);
                    power_sav.setEnabled(true);
                } else {
                    chunk_size.setEnabled(false);
                    num_threads.setEnabled(false);
                    comp_const.setEnabled(false);
                    comp_ratio.setEnabled(false);
                    net_speed.setEnabled(false);
                    power_sav.setEnabled(false);
                }
            }
        });

        // Set OnClickListener for update settings button
        Button updateSettings = (Button) layout.findViewById(R.id.updateSettingsButton);
        updateSettings.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Gets modified settings values
                String url = authURL.getText().toString();
                String user = username.getText().toString();
                String pass = password.getText().toString();
                Integer chunk = Integer.parseInt(chunk_size.getText().toString());
                Integer numT = Integer.parseInt(num_threads.getText().toString());
                Long max = Long.parseLong(max_size.getText().toString());
                Long thrs = Long.parseLong(threshold_size.getText().toString());
                Boolean adapt = use_adapt.isChecked();
                Boolean async = use_async.isChecked();
                Boolean bundle = use_bundle.isChecked();
                Float compC = Float.parseFloat(comp_const.getText().toString());
                Float compR = Float.parseFloat(comp_ratio.getText().toString());
                Integer netS = Integer.parseInt(net_speed.getText().toString());
                Boolean pPow = power_sav.isChecked();

                // Verifies if adaptive settings were modified, updates them if they were
                if(isModifiedAdapt(chunk, adapt, async, compC, compR, netS, pPow)) {
                    preferences.edit().putInt(UploadFileThread.CHUNK_PREF, chunk)
                            .putBoolean(UploadFileThread.ADAPT_PREF, adapt)
                            .putBoolean(UploadFileThread.ASYNC_PREF, async)
                            .putFloat(CompressAPI.SETTING_CONSTANT, compC)
                            .putFloat(CompressAPI.SETTING_RATIO, compR)
                            .putInt(CompressAPI.SETTING_SPEED, netS)
                            .putBoolean(CompressAPI.SETTING_POWER, pPow)
                            .commit();
                    CompressAPI.COMPRESSION_CONSTANT = compC;
                    CompressAPI.COMPRESSION_RATIO = compR;
                    CompressAPI.NETWORK_SPEED = netS;
                    CompressAPI.PREFER_POWER = pPow;
                }

                // Verifies if bundling settings were modified, updates them if they were
                if(isModifiedBundler(max, thrs, bundle)) {
                    try {
                        Bundler.destroyInstance();
                        preferences.edit().putLong(Bundler.MAX_PREF, max)
                                .putLong(Bundler.THRESHOLD_PREF, thrs)
                                .putBoolean(UploadFileThread.BUNDLE_PREF, bundle)
                                .commit();
                    } catch (CannotDestroyBundlerException ignore) {
                        Toast.makeText(getActivity(),
                                "Cannot change values while bundle isn't empty.",
                                Toast.LENGTH_SHORT).show();
                    }
                }

                // Verifies if number of threads was modified, updates and modifies it if it was
                if(isModifiedThreads(numT)) {
                    preferences.edit().putInt(UploadFileThread.THREADS_PREF, numT).commit();
                    try {
                        LibSwift swift = LibSwift.getInstance();
                        swift.modifyNumberOfThreads(numT);
                    } catch (LibSwiftNotInitializedException ignored) {}
                }

                // Verifies if authentication settings were modified, updates them and authenticates
                // user if they were
                if(isModified(url, user, pass)) {
                    LibSwift swift = LibSwift.initialize(url, user, pass, numT, getActivity());
                    swift.auth(((MainActivity) getActivity()));
                } else {
                    getActivity().getSupportFragmentManager().popBackStack();
                }
            }
        });

        // Sets OnClickListener for getting device admin privileges, disables button if the app
        // already has them
        final MainActivity activity = (MainActivity)getActivity();
        Boolean isAdmin = activity.manager.isAdminActive(activity.mDeviceAdmin);
        Button addDeviceAdmin = (Button) layout.findViewById(R.id.addDeviceAdmin);
        if(!isAdmin) {
            addDeviceAdmin.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Intent intent = new Intent(DevicePolicyManager.ACTION_ADD_DEVICE_ADMIN);
                    intent.putExtra(DevicePolicyManager.EXTRA_DEVICE_ADMIN, activity.mDeviceAdmin);
                    startActivityForResult(intent, MainActivity.ADMIN);
                }
            });
        } else {
            addDeviceAdmin.setEnabled(false);
        }

        return layout;
    }

    public boolean isModified(String authURL, String username, String password) {
        SharedPreferences preferences = getActivity().getSharedPreferences(MainActivity.PREFS_NAME,
                Context.MODE_PRIVATE);
        String url = preferences.getString(InitialLoadFragment.URL_PREF, null);
        String user = preferences.getString(InitialLoadFragment.USER_PREF, null);
        String pass = preferences.getString(InitialLoadFragment.PASS_PREF, null);

        return !((url != null && url.equals(authURL)) && (user != null && user.equals(username))
                && (pass != null && pass.equals(password)));
    }

    public boolean isModifiedAdapt(Integer chunk, Boolean adapt, Boolean async, Float compC,
                                   Float compR, Integer netS, Boolean pPow) {
        SharedPreferences preferences = getActivity()
                .getSharedPreferences(MainActivity.PREFS_NAME, Context.MODE_PRIVATE);
        Integer chunk_size = preferences
                .getInt(UploadFileThread.CHUNK_PREF, UploadFileThread.CHUNK_SIZE);

        Boolean use_adapt = preferences
                .getBoolean(UploadFileThread.ADAPT_PREF, UploadFileThread.USE_ADAPT);
        Boolean use_async = preferences
                .getBoolean(UploadFileThread.ASYNC_PREF, UploadFileThread.USE_ASYNC);

        Float comp_const = preferences.
                getFloat(CompressAPI.SETTING_CONSTANT, CompressAPI.COMPRESSION_CONSTANT);
        Float comp_ratio = preferences
                .getFloat(CompressAPI.SETTING_RATIO, CompressAPI.COMPRESSION_RATIO);
        Integer net_speed = preferences
                .getInt(CompressAPI.SETTING_SPEED, CompressAPI.NETWORK_SPEED);
        Boolean prefer_pow = preferences
                .getBoolean(CompressAPI.SETTING_POWER, CompressAPI.PREFER_POWER);

        return !(chunk_size.equals(chunk) && use_adapt.equals(adapt) && use_async.equals(async)
                && comp_const.equals(compC) && comp_ratio.equals(compR) && net_speed.equals(netS)
                && prefer_pow.equals(pPow));
    }

    public boolean isModifiedBundler(Long max, Long thrs, Boolean bundle) {
        SharedPreferences preferences = getActivity().getSharedPreferences(MainActivity.PREFS_NAME,
                Context.MODE_PRIVATE);

        Long max_size = preferences.getLong(Bundler.MAX_PREF, Bundler.MAX_SIZE);
        Long thrs_size = preferences.getLong(Bundler.THRESHOLD_PREF, Bundler.THRESHOLD_SIZE);

        Boolean use_bundle = preferences
                .getBoolean(UploadFileThread.BUNDLE_PREF, UploadFileThread.USE_BUNDLE);

        return !(max_size.equals(max) && thrs_size.equals(thrs) && use_bundle.equals(bundle));
    }

    public boolean isModifiedThreads(Integer numT) {
        SharedPreferences preferences = getActivity().getSharedPreferences(MainActivity.PREFS_NAME,
                Context.MODE_PRIVATE);
        Integer num_threads = preferences
                .getInt(UploadFileThread.THREADS_PREF, UploadFileThread.NUM_THREADS);

        return !num_threads.equals(numT);
    }
}
