package pt.afonsogarcia.swiftbox.bundling;

/**
 * CannotDestroyBundlerException is thrown when the app tries to modify the bundling thresholds
 * with files on the bundle.
 */
public class CannotDestroyBundlerException extends Exception {
}
