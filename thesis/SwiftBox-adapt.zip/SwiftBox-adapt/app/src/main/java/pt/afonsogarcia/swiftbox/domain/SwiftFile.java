package pt.afonsogarcia.swiftbox.domain;

/**
 * Representation of an object in the swift server.
 */
public class SwiftFile extends SwiftObject {
    private String contentType;
    private Integer size;

    /**
     * Creates a SwiftFile object
     * @param name the name of the object
     * @param size the size of the object
     * @param contentType the content type of the object
     */
    public SwiftFile(String name, Integer size, String contentType) {
        super(name);
        this.size = size;
        this.contentType = contentType;
    }

    /**
     * Gets the content type
     * @return the content type
     */
    public String getContentType() {
        return contentType;
    }

    /**
     * Gets the object size
     * @return the object size
     */
    public Integer getSize() {
        return size;
    }
}
