package pt.afonsogarcia.swiftbox.libswift.threads;

import android.content.Context;
import android.content.SharedPreferences;
import android.util.Log;
import android.widget.Toast;

import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.params.HttpConnectionParams;
import org.apache.http.params.HttpParams;

import pt.afonsogarcia.swiftbox.R;
import pt.afonsogarcia.swiftbox.libswift.LibSwift;
import pt.afonsogarcia.swiftbox.ui.MainActivity;
import pt.afonsogarcia.swiftbox.ui.fragments.InitialLoadFragment;

/**
 * Thread responsible for authenticating the user with the swift server.
 */
public class AuthThread extends LibSwiftThread {
    private String authURL;
    private String username;
    private String password;
    private Integer numThreads;

    /**
     * Creates an AuthThread object
     * @param activity is an Android activity used to display the progress dialogs
     * @param authURL is the URL of the server for performing authentication
     * @param username is the username of the user to authenticate
     * @param password is the password of the user to authenticate
     * @param numThreads is the number of threads used to upload objects to the server
     */
    public AuthThread(MainActivity activity, String authURL, String username, String password,
                      Integer numThreads) {
        super(activity, false);
        this.authURL = authURL;
        this.username = username;
        this.password = password;
        this.numThreads = numThreads;
    }

    /**
     * Authenticates the user with the server
     */
    @Override
    @SuppressWarnings("deprecation")
    public void runWork() {
        HttpClient httpClient = new DefaultHttpClient();
        HttpParams params = httpClient.getParams();
        HttpConnectionParams.setConnectionTimeout(params, 5000);

        HttpGet get = new HttpGet(authURL);
        get.addHeader("X-Auth-User", username);
        get.addHeader("X-Auth-Key", password);

        try {
            HttpResponse response = httpClient.execute(get);
            if (response.getStatusLine().getStatusCode() >= 200 &&
                    response.getStatusLine().getStatusCode() < 300) {
                SharedPreferences.Editor preferences = activity.getSharedPreferences(
                        MainActivity.PREFS_NAME, Context.MODE_PRIVATE).edit();
                preferences.putString(InitialLoadFragment.URL_PREF, authURL);
                preferences.putString(InitialLoadFragment.USER_PREF, username);
                preferences.putString(InitialLoadFragment.PASS_PREF, password);
                preferences.putInt(UploadFileThread.THREADS_PREF, numThreads);
                preferences.commit();

                // Initializes the LibSwift instance
                LibSwift swift = LibSwift.getInstance();
                swift.setAuthToken(response.getFirstHeader("X-Storage-Url").getValue(),
                        response.getFirstHeader("X-Storage-Token").getValue());

                // Reads the folder structure on the server and creates the
                // SwiftObject representations
                swift.getRootFolder(activity);
            } else {
                showErrorToast();
            }
        } catch (Exception e) {
            Log.e("AuthThread", e.getMessage());
            showErrorToast();
        }
    }

    /**
     * Displays a toast if there is an error authenticating the user
     */
    private void showErrorToast() {
        activity.runOnUiThread(new Runnable() {
            @Override
            public void run() {
                Toast.makeText(activity, R.string.could_not_authenticate, Toast.LENGTH_LONG)
                        .show();
            }
        });
    }
}
