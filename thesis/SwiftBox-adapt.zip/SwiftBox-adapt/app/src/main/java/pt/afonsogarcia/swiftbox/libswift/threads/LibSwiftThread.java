package pt.afonsogarcia.swiftbox.libswift.threads;

import android.util.Log;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;

import pt.afonsogarcia.swiftbox.libautomator.LibAutomator;
import pt.afonsogarcia.swiftbox.ui.MainActivity;

/**
 * LibSwiftThread is an abstract class that implements the progress dialogs for all threads and
 * measurements (time and energy automation) for tasks that require measurements.
 */
public abstract class LibSwiftThread extends Thread {
    final MainActivity activity;
    private Boolean profile;

    /**
     * Initializes the LibSwiftThread parameters
     * @param activity is an Android activity used to display the progress dialogs
     * @param profile is a flag used to control whether to measure data or not
     */
    public LibSwiftThread(MainActivity activity, Boolean profile) {
        this.activity = activity;
        this.profile = profile;
    }

    /**
     * Method responsible for performing the work
     */
    public void run() {
        try {
            showDialog();

            if (profile)
                LibAutomator.startMeasurements(false, false);

            runWork();

            if (profile) {
                Double duration = LibAutomator.stopMeasurements(false, false);
                Log.i("LibSwiftThread", "Execution took " + duration + "s");
            }

            dismissDialog();
        } catch (Exception e) {
            Log.e("LibSwiftThread", e.getMessage());
        }
    }

    /**
     * Method responsible for performing the specific task work (overriden by subclasses
     */
    public abstract void runWork();

    /**
     * Auxiliary method to convert the content of an InputStream to a String
     * @param is the InputStream containing the content
     * @return the content in String form
     */
    protected static String convertStreamToString(InputStream is) {
    /*
     * To convert the InputStream to String we use the BufferedReader.readLine()
     * method. We iterate until the BufferedReader return null which means
     * there's no more data to read. Each line will appended to a StringBuilder
     * and returned as String.
     */
        BufferedReader reader = new BufferedReader(new InputStreamReader(is));
        StringBuilder sb = new StringBuilder();

        String line;
        try {
            while ((line = reader.readLine()) != null) {
                sb.append(line).append("\n");
            }
        } catch (IOException e) {
            Log.e("LibSwiftThread", e.getMessage());
        } finally {
            try {
                is.close();
            } catch (IOException e) {
                Log.e("LibSwiftThread", e.getMessage());
            }
        }
        return sb.toString();
    }

    /**
     * Displays the progress dialog
     */
    public void showDialog() {
        activity.runOnUiThread(new Runnable() {
            @Override
            public void run() {
                activity.showDialog();
            }
        });
    }

    /**
     * Hides the progress dialog
     */
    public void dismissDialog() {
        activity.runOnUiThread(new Runnable() {
            @Override
            public void run() {
                activity.dismissDialog();
            }
        });
    }
}
