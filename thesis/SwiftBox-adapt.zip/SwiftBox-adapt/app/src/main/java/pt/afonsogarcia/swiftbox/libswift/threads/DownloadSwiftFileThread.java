package pt.afonsogarcia.swiftbox.libswift.threads;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.SharedPreferences;
import android.os.Environment;
import android.util.Log;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;

import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.zip.InflaterInputStream;

import pt.afonsogarcia.swiftbox.R;
import pt.afonsogarcia.swiftbox.domain.SwiftFile;
import pt.afonsogarcia.swiftbox.libswift.LibSwift;
import pt.afonsogarcia.swiftbox.ui.MainActivity;

public class DownloadSwiftFileThread extends LibSwiftThread {
    private SwiftFile file;
    private ProgressDialog dialog;

    public DownloadSwiftFileThread(MainActivity activity, SwiftFile file) {
        super(activity, true);
        this.file = file;

        SharedPreferences preferences = activity.getSharedPreferences(MainActivity.PREFS_NAME,
                Context.MODE_PRIVATE);
        if (preferences.contains(UploadFileThread.ADAPT_PREF)) {
            UploadFileThread.USE_ADAPT = preferences.getBoolean(UploadFileThread.ADAPT_PREF,
                    UploadFileThread.USE_ADAPT);
        }
    }

    @Override
    @SuppressWarnings("deprecation")
    public void runWork() {
        try {
            LibSwift swift = LibSwift.getInstance();
            HttpClient client = swift.getHttpClient();
            HttpGet get = swift.getRawHttpGet(file.getFullPath());
            if(UploadFileThread.USE_ADAPT)
                get.addHeader("X-Get-Compressed", "true");
            HttpResponse response = client.execute(get);
            if(response.getStatusLine().getStatusCode() >= 200 &&
                    response.getStatusLine().getStatusCode() < 300 &&
                    isExternalStorageWritable()) {
                HttpEntity entity = response.getEntity();
                long contentLength = entity.getContentLength();
                InputStream in;
                if (UploadFileThread.USE_ADAPT)
                    in = new InflaterInputStream(entity.getContent());
                else
                    in = new BufferedInputStream(entity.getContent());
                OutputStream out = new FileOutputStream(getStorageDir(file.getName()));
                byte data[] = new byte[1024];
                long total = 0;
                int count;

                while ((count = in.read(data)) != -1) {
                    total += count;
                    setProgress((int)((total*100)/contentLength));
                    out.write(data, 0, count);
                }

                in.close();
                out.flush();
                out.close();
            }
            swift.returnHttpClient(client);
        } catch (Exception e) {
            Log.e("DownloadSwiftFileThread", e.getMessage());
        }
    }

    @Override
    public void showDialog() {
        activity.runOnUiThread(new Runnable() {
            @Override
            public void run() {
                dialog = activity.showProgressDialog(R.string.downloading, 100);
            }
        });
    }

    private void setProgress(final int progrss) {
        activity.runOnUiThread(new Runnable() {
            @Override
            public void run() {
                dialog.setProgress(progrss);
            }
        });
    }

    private boolean isExternalStorageWritable() {
        String state = Environment.getExternalStorageState();
        return Environment.MEDIA_MOUNTED.equals(state);
    }

    private File getStorageDir(String fileName) {
        File file = new File(Environment.
                getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS), fileName);
        if(!file.getParentFile().mkdirs()) {
            Log.e("DownloadSwiftFileThread", "Directory not created");
        }
        return file;
    }
}
