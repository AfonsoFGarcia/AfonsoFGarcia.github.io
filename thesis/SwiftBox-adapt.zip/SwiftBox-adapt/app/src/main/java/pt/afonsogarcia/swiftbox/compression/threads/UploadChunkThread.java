package pt.afonsogarcia.swiftbox.compression.threads;

import android.util.Log;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpPut;
import org.apache.http.entity.ByteArrayEntity;

import java.util.NoSuchElementException;

import pt.afonsogarcia.swiftbox.compression.FifoTS;
import pt.afonsogarcia.swiftbox.libswift.LibSwift;
import pt.afonsogarcia.swiftbox.libswift.exceptions.LibSwiftNotInitializedException;

/**
 * Thread responsible for uploading the chunks to the server.
 */
public class UploadChunkThread extends Thread {

    // Used to kill thread when changing number of upload threads
    private Boolean run = true;

    /**
     * Method responsible for performing the work
     */
    @Override
    @SuppressWarnings("deprecation")
    public void run() {
        try {
            // Gets instances of LibSwift, FifoTS and HttpClient
            LibSwift swift = LibSwift.getInstance();
            HttpClient client = swift.getHttpClient();
            FifoTS fifo = FifoTS.getInstance();

            // Run until thread is killed
            //noinspection InfiniteLoopStatement
            while (run) {
                try {
                    // Get chunk from fifo (blocks if none available)
                    FifoTS.FifoElem chunk = fifo.popFifo();

                    // If the thread is supposed to be dead, put the chunk back and return
                    if(!run) {
                        fifo.pushFifo(chunk.getIndex(), chunk.getFileData(), chunk.getFilePath());
                        return;
                    }

                    // Upload the chunk to the server
                    HttpPut put = swift.getHttpPut(chunk.getFilePath());
                    put.addHeader("X-Chunk-Index", chunk.getIndex().toString());
                    HttpEntity entity = new ByteArrayEntity(chunk.getFileData());
                    put.setEntity(entity);

                    // Get the server response
                    final HttpResponse response = client.execute(put);
                    response.getEntity().consumeContent();
                    int statusCode = response.getStatusLine().getStatusCode();

                    // Set failed flag if an error occured (no retry is attempted)
                    if (!(statusCode >= 200 && statusCode < 300)) {
                        swift.setFailedFlag();
                    }

                    // Increment the number of processed chunks
                    swift.incrementProcessedChunks();
                } catch (NoSuchElementException ignored) {
                } catch (Exception e) {
                    Log.d("UploadFileThread", e.getMessage());
                    swift.setFailedFlag();
                    swift.incrementProcessedChunks();
                }
            }
        } catch (InterruptedException | LibSwiftNotInitializedException e) {
            Log.d("UploadFileThread", e.getMessage());
            try {
                LibSwift.getInstance().setFailedFlag();
            } catch (LibSwiftNotInitializedException e1) {
                e1.printStackTrace();
            }
        }
    }

    /**
     * Sets the run flag to false in order to kill the thread
     */
    public void killThread() {
        run = false;
    }
}
