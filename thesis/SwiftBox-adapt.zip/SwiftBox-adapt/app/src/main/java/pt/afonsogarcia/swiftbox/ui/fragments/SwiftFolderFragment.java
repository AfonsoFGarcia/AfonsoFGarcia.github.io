package pt.afonsogarcia.swiftbox.ui.fragments;

import android.annotation.SuppressLint;
import android.content.ContentResolver;
import android.net.Uri;
import android.os.Bundle;
import android.support.v4.app.FragmentTransaction;
import android.support.v4.app.ListFragment;
import android.support.v7.app.ActionBarActivity;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import pt.afonsogarcia.swiftbox.R;
import pt.afonsogarcia.swiftbox.domain.SwiftFolder;
import pt.afonsogarcia.swiftbox.domain.SwiftObject;
import pt.afonsogarcia.swiftbox.libswift.threads.UploadFileThread;
import pt.afonsogarcia.swiftbox.ui.MainActivity;
import pt.afonsogarcia.swiftbox.ui.exceptions.FragmentFactoryException;
import pt.afonsogarcia.swiftbox.ui.helper.FolderList;
import pt.afonsogarcia.swiftbox.ui.helper.FragmentFactory;

public class SwiftFolderFragment extends ListFragment {
    private SwiftFolder values;
    ArrayAdapter<SwiftObject> adapter;

    public SwiftFolderFragment() {}

    @SuppressLint("ValidFragment")
    public SwiftFolderFragment(SwiftFolder folder) {
        this.values = folder;
    }

    @Override
    @SuppressWarnings("deprecation")
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        super.onCreateView(inflater, container, savedInstanceState);

        if(savedInstanceState != null) {
            values = (SwiftFolder) savedInstanceState.getSerializable("VALUES");
        }

        ((MainActivity)getActivity()).setMenu(true);

        //noinspection ConstantConditions
        ((ActionBarActivity)getActivity()).getSupportActionBar().setTitle(values.getName());
        View rootView = inflater.inflate(R.layout.folder_view, container, false);
        adapter = new FolderList(getActivity(), values.getObjects());
        setListAdapter(adapter);
        return rootView;
    }

    @Override
    public void onSaveInstanceState(Bundle outState) {
        outState.putSerializable("VALUES", this.values);
        super.onSaveInstanceState(outState);
    }

    @Override
    public void onListItemClick(ListView l, View v, int position, long id) {
        final FragmentTransaction ft = getActivity().getSupportFragmentManager().beginTransaction();
        try {
            ft.replace(R.id.fragment, FragmentFactory
                    .getFragmentFor(values.getObjects().get(position)));
            ft.addToBackStack(null);
            ft.commit();
        } catch (FragmentFactoryException e) {
            Log.e("SwiftFolderFragment", e.getMessage());
        }
    }

    public SwiftFolder getFolder() {
        return values;
    }

    public void addSwiftObject() {
        adapter = new FolderList(getActivity(), values.getObjects());
        setListAdapter(adapter);
    }

    public void uploadFile(Uri file) {
        ContentResolver resolver = getActivity().getContentResolver();
        new UploadFileThread((MainActivity)getActivity(), file, resolver, this).start();
    }
}
