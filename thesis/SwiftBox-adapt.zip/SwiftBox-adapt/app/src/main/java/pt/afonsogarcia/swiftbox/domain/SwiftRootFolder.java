package pt.afonsogarcia.swiftbox.domain;

/**
 * Representation of the root folder in the swift server.
 * The root folder is an account.
 */
public class SwiftRootFolder extends SwiftFolder {
    /**
     * Creates a SwiftRootFolder object
     */
    public SwiftRootFolder() {
        super("SwiftBox");
    }

    /**
     * Gets the full path (override to not return SwiftBox)
     * @return the full path
     */
    @Override
    public String getFullPath() {
        return "";
    }
}
