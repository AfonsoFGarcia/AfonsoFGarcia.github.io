package pt.afonsogarcia.swiftbox.libswift.threads;

import android.util.Log;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.json.JSONArray;
import org.json.JSONObject;

import java.io.InputStream;

import pt.afonsogarcia.swiftbox.domain.SwiftFile;
import pt.afonsogarcia.swiftbox.domain.SwiftFolder;
import pt.afonsogarcia.swiftbox.domain.SwiftRootFolder;
import pt.afonsogarcia.swiftbox.libswift.LibSwift;
import pt.afonsogarcia.swiftbox.ui.MainActivity;

/**
 * Thread responsible for obtaining the folder structure from the swift server.
 */
public class SwiftRootFolderThread extends LibSwiftThread {
    private String result = "";
    private LibSwift swift;

    /**
     * Creates a SwiftRootFolderThread object
     * @param activity is an Android activity used to display the progress dialogs
     */
    public SwiftRootFolderThread(MainActivity activity) {
        super(activity, false);
    }

    /**
     * Reads the folder structure from the server
     */
    @Override
    @SuppressWarnings("deprecation")
    public void runWork() {
        try {
            // Get LibSwift instance
            swift = LibSwift.getInstance();

            // Wait until user is authenticated
            while (true) {
                if (swift.isAuthed()) break;
            }

            // Get containers
            HttpClient client = swift.getHttpClient();
            HttpGet get = swift.getHttpGet();
            HttpResponse response = client.execute(get);
            HttpEntity entity = response.getEntity();

            // Convert response to String
            if(entity != null) {
                InputStream in = entity.getContent();
                result = convertStreamToString(in);
                in.close();
            }

            // Parse response and create folders
            final SwiftRootFolder rootFolder = generateSwiftRootFolder();

            // Display the root folder on the UI
            activity.runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    activity.displayRootFolder(rootFolder);
                }
            });

            swift.returnHttpClient(client);
        } catch (Exception e) {
            Log.e("SwiftRootFolderThread", e.getMessage());
        }
    }

    /**
     * Parses the root folder content and creates the folder structure
     * @return the representation of the folder structure
     */
    private SwiftRootFolder generateSwiftRootFolder() {
        SwiftRootFolder folder = new SwiftRootFolder();

        try {
            JSONArray folders = new JSONArray(result);
            parseJsonArray(folders, folder); // Parses the array and creates the folder structure
        } catch (Exception e) {
            Log.e("SwiftRootFolderThread", e.getMessage());
        }

        return folder;
    }

    /**
     * Generates the folder structure for a specific container
     * @param folder is the representation of the container
     */
    @SuppressWarnings("deprecation")
    private void generateSwiftFolder(SwiftFolder folder) {
        try {
            // Get the content of the container
            HttpClient client = swift.getHttpClient();
            HttpGet get = swift.getHttpGet(folder.getFullPath());
            HttpResponse response = client.execute(get);
            
            HttpEntity entity = response.getEntity();

            // Parses the response and creates the folder structure
            if(entity != null) {
                InputStream in = entity.getContent();
                JSONArray result = new JSONArray(convertStreamToString(in));
                in.close();

                parseJsonArray(result, folder);
            }
            swift.returnHttpClient(client);
        } catch (Exception e) {
            Log.e("SwiftRootFolderThread", e.getMessage());
        }
    }

    /**
     * Parses a JSON array and creates a folder structure with the array data
     * @param array is a JSON array containing the folder structure
     * @param folder is a representation of the folder being parsed
     */
    private void parseJsonArray(JSONArray array, SwiftFolder folder) {
        for(int i = 0; i < array.length(); i++) {
            try {
                JSONObject object = array.getJSONObject(i);
                String name = object.getString("name");

                // If the folder being parsed is the root folder, further GETs must be made to the
                // server to obtain the child folders' content
                if(folder instanceof SwiftRootFolder) {
                    SwiftFolder auxFolder = new SwiftFolder(name);
                    folder.addObject(auxFolder);
                    generateSwiftFolder(auxFolder);
                    continue;
                }

                // Split the name into the folders
                String[] sub = name.split("/");

                // Searches the hierarchy for the correct folder
                SwiftFolder auxFolder = folder;
                for (int j = 0; j < sub.length - 1; j++) {
                    auxFolder = (SwiftFolder) auxFolder.getObject(sub[j]);
                }

                // Creates folder if content type is application/directory, otherwise creates file
                if (object.getString("content_type").equals("application/directory"))
                    auxFolder.addObject(new SwiftFolder(sub[sub.length-1]));
                else
                    auxFolder.addObject(new SwiftFile(sub[sub.length-1], object.getInt("bytes"),
                            object.getString("content_type")));
            } catch (Exception e) {
                Log.e("SwiftRootFolderThread", e.getMessage());
            }
        }
    }
}
