package pt.afonsogarcia.swiftbox.compression;

import android.app.Activity;
import android.content.Context;
import android.content.SharedPreferences;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.telephony.TelephonyManager;
import android.util.Log;

import java.lang.reflect.Method;

import pt.afonsogarcia.swiftbox.ui.MainActivity;

/**
 * Class responsible for implementing the adaptive compression and for deciding whether to use ir
 * or not.
 */
public class CompressAPI {
    private Integer compressionLevel;
    private Boolean compress;

    private Activity activity;

    // Parameters for the decision formula
    public static Float COMPRESSION_CONSTANT = 0.028652f;
    public static Float COMPRESSION_RATIO = 2.6404f;
    public static Integer NETWORK_SPEED = 20480;
    public static Boolean PREFER_POWER = true;

    public static String SETTING_CONSTANT = "SETTING_CONSTANT";
    public static String SETTING_RATIO = "SETTING_RATIO";
    public static String SETTING_SPEED = "SETTING_SPEED";
    public static String SETTING_POWER = "SETTING_POWER";

    private static CompressAPI instance;

    /**
     * Private constructor for the class (used for the singleton pattern)
     * @param mainActivity is an Android activity for getting access to network information
     */
    private CompressAPI(Activity mainActivity) {
        this.compressionLevel = 0;
        this.activity = mainActivity;

        SharedPreferences preferences = mainActivity.getSharedPreferences(MainActivity.PREFS_NAME,
                Context.MODE_PRIVATE);

        Float compressionConstant = preferences.getFloat(CompressAPI.SETTING_CONSTANT,
                CompressAPI.COMPRESSION_CONSTANT);
        Float compressionRatio = preferences.getFloat(CompressAPI.SETTING_RATIO,
                CompressAPI.COMPRESSION_RATIO);
        Integer networkSpeed = preferences.getInt(CompressAPI.SETTING_SPEED,
                CompressAPI.NETWORK_SPEED);
        Boolean preferPower = preferences.getBoolean(CompressAPI.SETTING_POWER,
                CompressAPI.PREFER_POWER);

        COMPRESSION_CONSTANT = compressionConstant;
        COMPRESSION_RATIO = compressionRatio;
        NETWORK_SPEED = networkSpeed;
        PREFER_POWER = preferPower;
    }

    /**
     * Implements the singleton pattern for the class
     * @param mainActivity is an Android activity for getting access to network information
     * @param compress is a flag to define if compression is applied to the chunks
     * @return instance of CompressAPI
     */
    public static CompressAPI getInstance(Activity mainActivity, Boolean compress) {
        if(instance == null) {
            instance = new CompressAPI(mainActivity);
        }
        instance.compress = compress;
        return instance;
    }

    /**
     * Sets the compression level to 0
     */
    public void resetLevel() {
        if(!compress)
            return;

        synchronized (this) {
            compressionLevel = 0;
        }
    }

    /**
     * Updates the compression level based on the FIFO size and size difference at the end of
     * compressing a chunk
     * @param diff is the size difference at the end of compressing a chunk
     */
    public void updateLevel(Integer diff) {
        if(!compress)
            return;

        Integer newLevel;
        Integer fifoSize = FifoTS.getInstance().getFifoSize();

        synchronized (this) {
            newLevel = compressionLevel;
        }

        if(fifoSize < 10 && diff <= 0) {
            newLevel = newLevel / 2;
        } else if(fifoSize < 20) {
            if(diff > 0) {
                newLevel++;
            } else if(diff < 0) {
                newLevel--;
            }
        } else if(fifoSize < 30) {
            if(diff > 0) {
                newLevel += 2;
            } else if(diff < 0) {
                newLevel--;
            }
        } else if(diff > 0) {
            newLevel += 2;
        }

        if (newLevel > 9) {
            newLevel = 9;
        } else if (newLevel < 0) {
            newLevel = 0;
        }

        synchronized (this) {
            compressionLevel = newLevel;
        }
    }

    /**
     * Gets the current compression level
     * @return the compression level
     */
    public Integer getLevel() {
        if(!compress)
            return 0;

        synchronized (this) {
            return compressionLevel;
        }
    }

    // TODO: Implement lookup table for different compression ratios based on file type
    /**
     * Applies the decision formula to estimate if there are energy benefits to using adaptive
     * compression (always returns true if the user prefers performance)
     * @return the reached decision (use adaptive compression or not)
     */
    public Boolean useAdaptive() {
        if(!PREFER_POWER)
            return true;

        try {
            // Uses reflection to invoke the method that computes transmission power based on the
            // wireless technology used
            Method transmissionPower = this.getClass().getDeclaredMethod("transmissionPower"
                    + getNetworkType());
            transmissionPower.setAccessible(true);
            Float tP = (Float) transmissionPower.invoke(this);

            // Computes the decision
            Float dr = COMPRESSION_CONSTANT / (tP / NETWORK_SPEED) + 1 / COMPRESSION_RATIO;
            return dr < 1;
        } catch (Exception e) {
            Log.e("CompressAPI", e.getMessage());
            return false;
        }
    }

    /**
     * Computes the transmission power used for WiFi
     * @return the estimated transmission power
     */
    @SuppressWarnings("unused")
    private Float transmissionPowerWiFi() {
        return 0.0203f * NETWORK_SPEED + 235.89f;
    }

    // TODO: Get formula that estimates based on network data
    /**
     * Computes the transmission power used for LTE
     * @return the estimated transmission power
     */
    @SuppressWarnings("unused")
    private Float transmissionPowerLTE() {
        return 1760.54f;
    }

    // TODO: Get formula that estimates based on network data
    /**
     * Computes the transmission power used for 3G
     * @return the estimated transmission power
     */
    @SuppressWarnings("unused")
    private Float transmissionPower3G() {
        return 467.88f;
    }

    /**
     * Gets the network class (3G or LTE)
     * @return string representing the network class
     */
    private String getNetworkClass() {
        TelephonyManager telephonyManager = (TelephonyManager) activity
                .getSystemService(Context.TELEPHONY_SERVICE);
        Integer networkType = telephonyManager.getNetworkType();
        switch (networkType) {
            case TelephonyManager.NETWORK_TYPE_LTE:
                return "LTE";
            default:
                return "3G";
        }
    }

    /**
     * Gets the network type (WiFi, 3G or LTE)
     * @return string representing the network type
     */
    private String getNetworkType() {
        ConnectivityManager connectivityManager = (ConnectivityManager) activity
                .getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo info = connectivityManager.getActiveNetworkInfo();
        if(info != null && info.isConnected() && info.getType() == ConnectivityManager.TYPE_WIFI) {
            return "WiFi";
        } else {
            return getNetworkClass();
        }
    }
}
