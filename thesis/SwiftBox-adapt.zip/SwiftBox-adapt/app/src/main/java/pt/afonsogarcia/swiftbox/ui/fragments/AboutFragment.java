package pt.afonsogarcia.swiftbox.ui.fragments;

import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v7.app.ActionBarActivity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import pt.afonsogarcia.swiftbox.R;
import pt.afonsogarcia.swiftbox.ui.MainActivity;

public class AboutFragment extends Fragment {

    public AboutFragment() {
    }

    @Override
    @SuppressWarnings("deprecation")
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        //noinspection ConstantConditions
        ((ActionBarActivity)getActivity()).getSupportActionBar().setTitle("About");
        ((MainActivity)getActivity()).setMenu(false);
        return inflater.inflate(R.layout.fragment_about, container, false);
    }
}
