package pt.afonsogarcia.swiftbox.compression.threads;

import android.app.Activity;
import android.util.Log;

import org.apache.commons.io.IOUtils;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.zip.Deflater;
import java.util.zip.DeflaterOutputStream;

import pt.afonsogarcia.swiftbox.compression.CompressAPI;
import pt.afonsogarcia.swiftbox.compression.FifoTS;
import pt.afonsogarcia.swiftbox.libautomator.LibAutomator;
import pt.afonsogarcia.swiftbox.libswift.LibSwift;
import pt.afonsogarcia.swiftbox.libswift.exceptions.LibSwiftNotInitializedException;
import pt.afonsogarcia.swiftbox.libswift.threads.UploadFileThread;

/**
 * Thread responsible for splitting a file into chunks of a predefined size and compressing them.
 */
public class CreateChunkThread extends Thread {

    private Activity activity;

    /**
     * Initializes the thread
     * @param activity is an Android activity used for passing to the CompressAPI class
     */
    public CreateChunkThread(Activity activity) {
        super();
        this.activity = activity;
    }

    /**
     * Method responsible for performing the work
     */
    @Override
    public void run() {
        // Get instances from CompressAPI and FifoTS
        CompressAPI compressAPI = CompressAPI.getInstance(activity, true);
        FifoTS fifo = FifoTS.getInstance();

        // Run until app is killed
        while(true) {
            try {
                // Reset the compression level each time a new file is received
                compressAPI.resetLevel();

                // Get LibSwift instance and get new file (blocks until file is available)
                LibSwift swift = LibSwift.getInstance();
                LibSwift.FileChunkData data = swift.getData();

                // Compression start time
                Long startTime = System.nanoTime();

                // For each chunk
                for (int i = 0; i < data.getChunkNumber(); i++) {
                    try {
                        // Get current FIFO size
                        Integer fifoSize = fifo.getFifoSize();

                        // Read CHUNK_SIZE bytes from file
                        byte chunkData[] = new byte[UploadFileThread.CHUNK_SIZE];
                        IOUtils.read(data.getInputStream(), chunkData);

                        // Compress chunk and put in FIFO
                        Integer level = compressAPI.getLevel();
                        byte[] finalData = compress(chunkData, level);
                        fifo.pushFifo(i, finalData, data.getFilePath());

                        // Calculate difference between FIFO size at start and now and update
                        // compression level.
                        Integer fifoDiff = fifo.getFifoSize() - fifoSize;
                        compressAPI.updateLevel(fifoDiff);
                    } catch (IOException e) {
                        swift.setFailedFlag();
                        swift.setFinalChunks(i + 1);
                        return;
                    }
                }

                // Log compression time
                Long totalTime = System.nanoTime() - startTime;
                Log.i("CreateChunkThread", "Total compression time: " + LibAutomator.
                        round(totalTime / 1000000000d));
            } catch (LibSwiftNotInitializedException | InterruptedException ignored) {
            }
        }
    }

    /**
     * Compresses a byte array of data to another byte array
     * @param data is the byte array to compress
     * @param level is the level at which to compress
     * @return a byte array with the compressed data
     * @throws IOException if there is an error with ByteArrayOutputStream or DeflaterOutputStream
     */
    private byte[] compress(byte[] data, Integer level) throws IOException {
        Deflater deflater = new Deflater();
        deflater.setLevel(level);

        ByteArrayOutputStream out = new ByteArrayOutputStream();
        DeflaterOutputStream dos = new DeflaterOutputStream(out, deflater);
        dos.write(data);
        dos.finish();

        return out.toByteArray();
    }
}
