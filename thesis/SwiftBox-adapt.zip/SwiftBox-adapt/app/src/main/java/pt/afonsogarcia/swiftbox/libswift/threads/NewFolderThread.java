package pt.afonsogarcia.swiftbox.libswift.threads;

import android.util.Log;

import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpPut;

import pt.afonsogarcia.swiftbox.domain.SwiftFolder;
import pt.afonsogarcia.swiftbox.libswift.LibSwift;
import pt.afonsogarcia.swiftbox.ui.MainActivity;
import pt.afonsogarcia.swiftbox.ui.fragments.SwiftFolderFragment;

/**
 * Thread responsible for creating a new folder on the swift server.
 * A folder can be a container (if it is in the root level) or an object of type
 * application/directory otherwise.
 */
public class NewFolderThread extends LibSwiftThread {
    private SwiftFolder folder;
    private SwiftFolderFragment fragment;

    /**
     * Creates a NewFolderThread object
     * @param activity is an Android activity used to display the progress dialogs
     * @param folder is the representation of the new folder
     * @param fragment is the fragment of the parent folder
     */
    public NewFolderThread(MainActivity activity, SwiftFolder folder,
                           SwiftFolderFragment fragment) {
        super(activity, false);
        this.folder = folder;
        this.fragment = fragment;
    }

    /**
     * Creates the new folder in the server
     */
    @Override
    @SuppressWarnings("deprecation")
    public void runWork() {
        try {
            // Get instances of LibSwift and HttpClient
            LibSwift swift = LibSwift.getInstance();
            HttpClient client = swift.getHttpClient();

            // Create the PUT request and execute it
            HttpPut put = swift.getHttpPut(folder.getFullPath());
            put.addHeader("Content-Type", "application/directory"); // Ignored if container
            put.addHeader("X-No-Compress", "true");
            HttpResponse response = client.execute(put);

            // Get response
            response.getEntity().consumeContent();
            int statusCode = response.getStatusLine().getStatusCode();

            // Add folder to the view if successful
            if(statusCode >= 200 && statusCode < 300)
                fragment.getActivity().runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        fragment.addSwiftObject();
                    }
                });
            swift.returnHttpClient(client);
        } catch (Exception e) {
            Log.e("NewFolderThread", e.getMessage());
        }
    }
}
