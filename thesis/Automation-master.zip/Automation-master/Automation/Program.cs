﻿using System;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading;

namespace Automation
{
    class UDPAutomator
    {
        // Index of file to save
        private static int file_num = 1;

        // Wait time until reply
        private static int small_time = 2500;

        // Use to measure times less than 1 second (activates wait time)
        private static bool small_measures = true;

        // Deactivate power measure without changing app
        private static bool no_measures = true;

        // Print when sample stopped
        static void OnSampleStopped()
        {
            Console.WriteLine("Event: Automation.SampleStopped()");
        }

        // Print when power monitor is disconnected
        static void OnDeviceDisconnected()
        {
            Console.WriteLine("Event: Automation.DeviceDisconnected()");
        }

        // Print when exception is raised
        static void OnUnhandledException(Exception e)
        {
            Console.WriteLine("Event: Automation.UnhandledException(e.Message=\"{0}\")",
                               e.Message);
        }

        // Execute when power monitor window is closed
        static void OnApplicationClosed(PowerTool.ExitCode exitCode)
        {
            Environment.Exit(1);
        }

        // Server port
        private const int listenPort = 50000;

        [STAThread]
        public static int Main(string[] args)
        {
            // Get power monitor
            PowerTool.Automation powerTool = new PowerTool.Automation();

            // Timeout for communication with power monitor
            const uint waitLimit = 30;

            // Prepare power monitor
            if (!no_measures)
            {
                // Register callbacks
                powerTool.OnSampleStopped += OnSampleStopped;
                powerTool.OnDeviceDisconnected += OnDeviceDisconnected;
                powerTool.OnUnhandledException += OnUnhandledException;
                powerTool.OnApplicationClosed += OnApplicationClosed;

                ushort[] serialNumbers = null;
                uint deviceCount = 0;
                const bool iniFile = false;

                // Get connected power monitors
                deviceCount = powerTool.EnumerateDevices(out serialNumbers);

                if (deviceCount == 0)
                {
                    Console.WriteLine("No devices found");
                    return -1;
                }

                // Open power monitor software
                bool result = powerTool.OpenApplication(iniFile, waitLimit);

                if (!result)
                {
                    Console.WriteLine("Failed to start PowerTool");
                    return -1;
                }

                ushort serialNumber = serialNumbers[0];

                // Connect to first power monitor
                if (!powerTool.ConnectDevice(serialNumber))
                {
                    Console.WriteLine("Failed to open device");
                    powerTool.CloseApplication(iniFile, waitLimit);
                    return -1;
                }

                result = false;

                // Set properties for capture
                try
                {
                    powerTool.Visible = true;
                    powerTool.WindowState = PowerTool.WindowState.Maximized;
                    powerTool.CaptureMainCurrent = true;
                    powerTool.CaptureUsbCurrent = false;
                    powerTool.CaptureAuxCurrent = false;
                    powerTool.VoltageChannel = PowerTool.Channel.Main;
                    powerTool.UsbPassthroughMode = PowerTool.UsbPassthroughMode.Auto;
                    powerTool.BatterySize = 2100; // Battery capacity in mAh
                    powerTool.MainOutputVoltageSetting = 3.8f; // Battery voltage in V
                    powerTool.EnableMainOutputVoltage = true;
                    powerTool.TriggerSetting = "ATA";
                    result = true;
                }
                catch (Exception e)
                {
                    Console.WriteLine(e.Message);
                }

                if (!result)
                {
                    Console.WriteLine("Error encountered while setting properties");

                    if (powerTool.DeviceIsConnected)
                        powerTool.DisconnectDevice();

                    if (powerTool.ApplicationIsOpen)
                        powerTool.CloseApplication(iniFile, waitLimit);

                    return -1;
                }
            }

            // Open UDP socket
            UdpClient listener = new UdpClient(listenPort);
            IPEndPoint groupEP = new IPEndPoint(IPAddress.Any, listenPort);

            string received_data;
            byte[] received_byte_array;
            byte[] ok_byte_array, fail_byte_array;

            bool profiling = false;
            bool done = false;

            try
            {
                while (!done)
                {
                    Console.WriteLine("\n\nWaiting for commands...");

                    // Receive data from smartphone
                    received_byte_array = listener.Receive(ref groupEP);
                    Console.WriteLine("Received broadcast from {0}", groupEP.ToString());

                    // Read received data
                    received_data = Encoding.ASCII.GetString(received_byte_array, 0, received_byte_array.Length);
                    fail_byte_array = Encoding.ASCII.GetBytes("FAIL");
                    ok_byte_array = Encoding.ASCII.GetBytes("OK");

                    if (!profiling && received_data.Equals("ON"))
                    {
                        Console.WriteLine("Received ON");
                        if (no_measures)
                        {
                            listener.Send(ok_byte_array, ok_byte_array.Length, groupEP);
                            profiling = true;
                        }
                        else
                        {
                            // Start sampling
                            if (!powerTool.StartSampling(waitLimit))
                            {
                                Console.WriteLine("Failed to start sampling");
                                listener.Send(fail_byte_array, fail_byte_array.Length, groupEP);
                            }
                            else
                            {
                                profiling = true;
                                if (small_measures)
                                    Thread.Sleep(small_time);
                                listener.Send(ok_byte_array, ok_byte_array.Length, groupEP);
                            }
                        }
                    }
                    else if (profiling && received_data.Equals("OFF"))
                    {
                        Console.WriteLine("Received OFF");
                        if (no_measures)
                        {
                            listener.Send(ok_byte_array, ok_byte_array.Length, groupEP);
                            profiling = false;
                        }
                        else
                        {
                            // Stop sampling
                            powerTool.StopSampling(waitLimit);
                            listener.Send(ok_byte_array, ok_byte_array.Length, groupEP);

                            // Store traces
                            if (powerTool.HasData)
                            {
                                string store = "C:\\\\Users\\Afonso F. Garcia\\Documents\\PowerTrace-"; // Change to desired location
                                powerTool.SaveFile(store + file_num++ + ".pt4", true, true);
                            }

                            profiling = false;
                        }
                    }
                    else
                    {
                        Console.WriteLine("Invalid command");
                        listener.Send(fail_byte_array, fail_byte_array.Length, groupEP);
                    }
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e.ToString());
            }
            listener.Close();
            return 0;
        }
    }
}
